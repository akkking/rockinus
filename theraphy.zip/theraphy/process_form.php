<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html><?php

$soap_s=$_POST['soap_s'];
$soap_O_Eval=$_POST['soap_O_Eval'];
$soap_O_M=$_POST['soap_O_M'];
$soap_O_M_box=$_POST['soap_O_M_box'];
$soap_O_M_box2=$_POST['soap_O_M_box2'];
$soap_O_M_box3=$_POST['soap_O_M_box3'];
$soap_O_M_box4=$_POST['soap_O_M_box4'];
$soap_O_M_box5=$_POST['soap_O_M_box5'];
$soap_O_M_box6=$_POST['soap_O_M_box6'];
$soap_O_M_box7=$_POST['soap_O_M_box7'];
$soap_O_M_box8=$_POST['soap_O_M_box8'];
$soap_O_M_box9=$_POST['soap_O_M_box9'];

$soap_O_TS=$_POST['soap_O_TS'];
$soap_O_TS_box=$_POST['soap_O_TS_box'];

$soap_O_Man=$_POST['soap_O_Man'];
$soap_O_Man_box=$_POST['soap_O_Man_box'];
$soap_O_Man_box2=$_POST['soap_O_Man_box2'];
$soap_O_Man_box3=$_POST['soap_O_Man_box3'];

$soap_O_ET=$_POST['soap_O_ET'];
$soap_O_MT=$_POST['soap_O_MT'];
$soap_O_BT=$_POST['soap_O_BT'];
$soap_O_BT_box=$_POST['soap_O_BT_box'];
$soap_O_ET_box=$_POST['soap_O_ET_box'];
$soap_O_GT=$_POST['soap_O_GT'];
$soap_O_SC=$_POST['soap_O_SC'];
$soap_O_SP=$_POST['soap_O_SP'];
$soap_O_TE=$_POST['soap_O_TE'];

$soap_PT_edu=$_POST['soap_PT_edu'];

$soap_A_EI=$_POST['soap_A_EI'];
$soap_A_EI_Box=$_POST['soap_A_EI_Box'];

$soap_O_Gait=$_POST['soap_O_Gait'];
$soap_O_Gait1=$_POST['soap_O_Gait1'];
$soap_O_Gait2=$_POST['soap_O_Gait2'];
$soap_O_Gait_Box=$_POST['soap_O_Gait_Box'];

$soap_A_RP=$_POST['soap_A_RP'];
$soap_A_RP_Box=$_POST['soap_A_RP_Box'];
$soap_A_P=$_POST['soap_A_P'];
$soap_A_P_Box=$_POST['soap_A_P_Box'];

$TP_ex=$_POST['TP_ex'];
$NM=$_POST['NM'];
$Man=$_POST['Man'];
$GT=$_POST['GT'];
$TM=$_POST['TM'];
$TT=$_POST['TT'];


$soap_name=$_POST['soap_name'];
$soap_date=$_POST['soap_date'];
$soap_trnum=$_POST['soap_trnum'];
$soap_license=$_POST['soap_license'];
$checkmark1=$_POST['checkmark1'];
$checkmark2=$_POST['checkmark2'];
$checkmark3=$_POST['checkmark3'];


//Write the info into the txt files, txt files are used to load data
$arr=explode("/",$soap_date);
$date=$arr[2].$arr[0].$arr[1];

$txtname = "txt/$soap_name/".$soap_name."_".$date.".txt";

$testdir = "txt/$soap_name/";
if(!file_exists($testdir))
{
	mkdir ($testdir,   0777); 
}

$fopen = fopen($txtname,'wb');//create the txt file of the patients 
$str=$checkmark1;
$str.="\n".$checkmark2;
$str.="\n".$checkmark3;
$str.="\n".$soap_name;
$str.="\n".$soap_date;
$str.="\n".$soap_trnum;
if(is_array($soap_license))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_license);
	//if(count($soap_license)==0)
	//$arr="soap_license";
	$str.="\n".$arr;
}
else if(count($soap_license)==0)
$str.="\n"."array";
$str.="\n".$soap_s;
$str.="\n"."...";
$str.="\n".$soap_O_Eval;
if(is_array($soap_O_SC))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_SC);
	$str.="\n".$arr;
}
else if(count($soap_O_SC)==0)
$str.="\n"."array";
$str.="\n".$soap_PT_edu;
$str.="\n"."...";
if(is_array($soap_O_BT))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_BT);
	$str.="\n".$arr;
}
else if(count($soap_O_BT)==0)
$str.="\n"."array";
$str.="\n".$soap_O_BT_box;
if(is_array($soap_O_SP))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_SP);
	$str.="\n".$arr;
}
else if(count($soap_O_SP))
$str.="\n"."array";
if(is_array($soap_O_ET))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_ET);
	$str.="\n".$arr;
}
else if(count($soap_O_ET))
$str.="\n"."array";
if(is_array($soap_O_GT))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_GT);
	$str.="\n".$arr;
}
else if(count($soap_O_GT))
$str.="\n"."array";
if(is_array($soap_O_Man))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_Man);
	$str.="\n".$arr;
}
else if(count($soap_O_Man))
$str.="\n"."array";
$str.="\n".$soap_O_Man_box;
$str.="\n".$soap_O_Man_box2;
$str.="\n".$soap_O_Man_box3;
if(is_array($soap_O_M))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_M);
	$str.="\n".$arr;
}
else if(count($soap_O_M))
$str.="\n"."array";
$str.="\n".$soap_O_M_box;
$str.="\n".$soap_O_M_box2;
$str.="\n".$soap_O_M_box3;
$str.="\n".$soap_O_M_box4;
$str.="\n".$soap_O_M_box5;
$str.="\n".$soap_O_M_box6;
$str.="\n".$soap_O_M_box7;
$str.="\n".$soap_O_M_box8;
$str.="\n".$soap_O_M_box9;
if(is_array($soap_O_MT))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_MT);
	$str.="\n".$arr;
}
else if(count($soap_O_MT))
$str.="\n"."array";
if(is_array($soap_O_TS))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_TS);
	$str.="\n".$arr;
}
else if(count($soap_O_TS))
$str.="\n"."array";
$str.="\n".$soap_O_TS_box;
if(is_array($soap_O_TE))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_O_TE);
	$str.="\n".$arr;
}
else if(count($soap_O_TE))
$str.="\n"."array";

if(is_array($soap_A_EI))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_A_EI);
	$str.="\n".$arr;
}
else if(count($soap_A_EI))
$str.="\n"."array";
$str.="\n".$soap_A_EI_Box;
$str.="\n"."...";
$str.="\n".$soap_O_Gait;
$str.="\n".$soap_O_Gait1;
$str.="\n".$soap_O_Gait2;
$str.="\n".$soap_O_Gait_Box;
$str.="\n"."...";

if(is_array($soap_A_RP))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_A_RP);
	$str.="\n".$arr;
}
else if(count($soap_A_RP))
$str.="\n"."array";
$str.="\n".$soap_A_RP_Box;
$str.="\n"."...";
if(is_array($soap_A_P))
{
	//$arr=$soap_license;
	$arr=implode("|",$soap_A_P);
	$str.="\n".$arr;
}
else if(count($soap_A_P))
$str.="\n"."array";
$str.="\n".$soap_A_P_Box;
$str.="\n"."...";
$str.="\n".$TP_ex;
$str.="\n".$NM;
$str.="\n".$Man;
$str.="\n".$GT;
$str.="\n".$TT;
$str.="\n".$TM;
$str.="\n";


fputs($fopen,$str);//write the info into the txt files 
fclose($fopen); 

//get the info from the txt file
//$file = file($txtname);
//foreach($file as &$line) echo $line.'<br />';

//Done
$modalities=array('soap_O_M_box','soap_O_M_box2','soap_O_M_box3','soap_O_M_box4','soap_O_M_box5','soap_O_M_box6','soap_O_M_box7','soap_O_M_box8');

$fontsize =12;
$space_var = 5;

$sentence_margin=80;
$cat_margin=480;


function no_join2($array)
{
	$causes = "";
	if(count($array) == 1){
		return $array[0];
	}
	else{
		for($i = 0; $i < count($array) - 1; $i++){
			$causes .= $array[$i] . ", ";
		}
		$causes .= "" . $array[count($array) - 1];
	}
	return $causes;
	
	
}


function p_choice($array)
{
	$causes = "";
	if(count($array) == 1){
		$causes = $array[0];
		//return $array[0];
		return $causes;
	}
	else{
		for($i = 0; $i < count($array) - 2; $i++){
			$causes .= $array[$i] . ", ";
		}
		$causes .= "" .$array[count($array) - 2];
		$causes .= " and " . $array[count($array) - 1];
	}
	return $causes;
	
	
}

function p_sentence($array)
{
	$causes = "";
	if(count($array) == 1){
		return $array[0];
	}
	else{
		for($i = 0; $i < count($array); $i++){
			$causes .= $array[$i] . ". " ;
		}
			
	}
	return $causes;
	
	
}


function add_to($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "ultrasound to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to1($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "electrical stimulation to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to2($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "anodyne to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to3($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "ETPS to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to4($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "cold laser to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to5($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "moist heat to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to6($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "cold pack to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}


function add_to7($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "iontophoresis to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to8($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "phonophoresis to")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
     //$mod=array($soap_O_M_box,$soap_O_M_box2);    
    return $box;   
}

function add_to9($array)
{
	$var1;
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "contrast bath")
		{
		    $var1= $array[$i]; 
         }
        
       
		  
		  
		  
     } 
     return $var1;
     
      
}

function add_to10($array)
{
	$var1;
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "biofeedback")
		{
		    $var1= $array[$i]; 
         }
        
       
		  
		  
		  
     } 
     return $var1;
     
      
}

function add_to11($array)
{
	$var1;
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "paraffin")
		{
		    $var1= $array[$i]; 
         }
        
       
		  
		  
		  
     } 
     return $var1;
     
      
}

function add_to12($array)
{
	$var1;
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "medi cupping massage")
		{
		    $var1= $array[$i]; 
         }
        
       
		  
		  
		  
     } 
     return $var1;
     
      
}

$mod1 = add_to($soap_O_M,$soap_O_M_box);
$mod2 = add_to1($soap_O_M,$soap_O_M_box2);
$mod3 = add_to2($soap_O_M,$soap_O_M_box3);
$mod4 = add_to3($soap_O_M,$soap_O_M_box4);
$mod5 = add_to4($soap_O_M,$soap_O_M_box5);
$mod6 = add_to5($soap_O_M,$soap_O_M_box6);
$mod7 = add_to6($soap_O_M,$soap_O_M_box7);
$mod8 = add_to7($soap_O_M,$soap_O_M_box8);
$mod9 = add_to8($soap_O_M,$soap_O_M_box9);




$mod10 =  add_to9($soap_O_M);
$mod11 =  add_to10($soap_O_M);
$mod12 =  add_to11($soap_O_M);
$mod13 =  add_to12($soap_O_M);

$mod_choice = array($mod1,$mod2,$mod3,$mod4,$mod5,$mod6,$mod7,$mod8,$mod9,$mod10,$mod11,$mod12,$mod13);

function chk_array($array)
{
	foreach($array as $key=> $value)
	{
		if($value=="" || $value == "" || is_null($value))
		{
			unset($array[$key]);
		}
	}
	
	$new_array=array_values($array);
	return $new_array;
	
}
			
	
function remove_element($array)
{
	foreach($array as $key=> $value)
	{
		if($value=="traction of" || $value == "traction of" )
		{
			unset($array[$key]);
		}
	}
	
	$new_array=array_values($array);
	return $new_array;
	
}

function sep_element($array,$box)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "traction of")
		{
		    $box= $array[$i] . $box;
         }
        
		  
		  
		  
     } 
       
    return $box;   
}

$Tst=remove_element($soap_O_TS);

$Tst_e=sep_element($soap_O_TS,$soap_O_TS_box);

array_push($Tst,"$Tst_e");
$new_Tst = chk_array($Tst);


$TrSt=p_choice($new_Tst);

$new_mod = chk_array($mod_choice);
$modality = p_choice($new_mod);

function sep_elementM1($array,$box1)
{
	
	
	

	
	for($i =0; $i<count($array); $i++)
	{
		if($array[$i] == "joint mobs of")
		{
		    $box1= $array[$i] . $box1;
         }
         
        
		  
		  
		  
     } 
         
    return $box1;   
}
function sep_elementM2($array,$box1)
{
    
    for($i =0; $i<count($array); $i++)
    {
    if($array[$i] == "manual traction to")
		{
		    $box1= $array[$i] . $box1;
         }
         
     }
     return $box1;    
}

function sep_elementM3($array,$box1)
{
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "massage to")
		{
		    $box1= $array[$i] . $box1;
         }
     }
     return $box1; 
}

function sep_elementM4($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "manual lymph drainage")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}
function sep_elementM5($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "taping")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}

function sep_elementM6($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "stump wrapping")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}

function sep_elementM7($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "stump care")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}

function sep_elementM8($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "chest physical therapy")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}

function sep_elementM9($array)
{
	$var;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "myofascial release")
		{
		    $var1= $array[$i] ;
         }
     }
     return $var1; 
}






$man1 = sep_elementM1($soap_O_Man,$soap_O_Man_box);
$man2 = sep_elementM2($soap_O_Man,$soap_O_Man_box2);
$man3 = sep_elementM3($soap_O_Man,$soap_O_Man_box3);
$man4 = sep_elementM4($soap_O_Man);
$man5 = sep_elementM5($soap_O_Man);
$man6 = sep_elementM6($soap_O_Man);
$man7 = sep_elementM7($soap_O_Man);
$man8 = sep_elementM8($soap_O_Man);
$man9 = sep_elementM9($soap_O_Man);

$man=array($man1,$man2,$man3,$man4,$man5,$man6,$man7,$man8,$man9);

$man_scrub = chk_array($man);

$new_man = p_choice($man_scrub);

$ET = p_choice($soap_O_ET);
$MT = p_choice($soap_O_MT);


function remove_element1($array)
{
	foreach($array as $key=> $value)
	{
		if($value=="bend-lift & carry exercise" || $value == "bend-lift & carry exercise" )
		{
			unset($array[$key]);
		}
	}
	
	$new_array=array_values($array);
	return $new_array;
	
}


function sep_elementBT($array,$box1)
{   $var1;$var2;
    for($i =0; $i<count($array); $i++)
    {
         if($array[$i] == "bend-lift & carry exercise")
		{
		    
		    unset($array[$i]);
		    $var1="bend-lift & carry exercise";
		    $var2=" lbs";
		    $box1=$var1 .  $box1 . $var2;
         }
     }
     return $box1; 
}



$balance = remove_element1($soap_O_BT);
$balance_box = sep_elementBT($soap_O_BT,$soap_O_BT_box);
array_push($balance,"$balance_box");
$balance_scrub = chk_array($balance);
$new_bal = p_choice($balance_scrub);

if(!empty($soap_A_EI_Box) and count($soap_A_EI)==0)
	{
	  $soap_A_EI=array("$soap_A_EI_Box");
	}
    
    else if(!empty($soap_A_EI_Box) and count($soap_A_EI)>=1)
	{
	  array_push($soap_A_EI,"$soap_A_EI_Box");
	}


$gT = p_choice($soap_O_GT);
$sC = p_choice($soap_O_SC);
$sP = p_choice($soap_O_SP);
$tE = p_choice($soap_O_TE);
$eI = p_choice($soap_A_EI);
$rehab_p = p_sentence($soap_A_RP);
$AP = p_sentence($soap_A_P);
//$AP = p_choice($soap_A_P);

$Thera_names=p_sentence($soap_license);

include ('class.ezpdf.php');
$pdf =& new Cezpdf();

$pdf->ezText("Righteous Rehab Inc. dba TOP Physical Therapy",center,14);

$pdf->ezImage("top.png",-15,50,"none","left",0);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

if(!empty($checkmark1))
{
$pdf->selectFont('./fonts/ZapfDingbats.afm','none');
$table_opt1= array(array('name'=>'4'));
$pdf->ezSetMargins(0,0,0,530);
$pdf->ezTable($table_opt1,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));
//$chmrk = $pdf->ezText("4",$fontsize);
$pdf->ezSetDy(12);
$pdf->ezSetMargins(0,0,40,0);
}
if(!empty($checkmark2))
{
$pdf->selectFont('./fonts/ZapfDingbats.afm','none');
$table_opt1= array(array('name'=>'4'));
$pdf->ezSetMargins(0,0,0,95);
$pdf->ezTable($table_opt1,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));
//$chmrk = $pdf->ezText("4",$fontsize);
$pdf->ezSetDy(14);
$pdf->ezSetMargins(0,0,40,0);
}

if(!empty($checkmark3))
{
$pdf->selectFont('./fonts/ZapfDingbats.afm','none');
$table_opt1= array(array('name'=>'4'));
$pdf->ezSetMargins(0,0,365,0);
$pdf->ezTable($table_opt1,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));
//$chmrk = $pdf->ezText("4",$fontsize);
$pdf->ezSetDy(15);
$pdf->ezSetMargins(0,0,40,0);
}

//$pdf->selectFont('./fonts/Helvetica.afm');
//$pdf->selectFont('./fonts/ZapfDingbats.afm','none');



$pdf->selectFont('./fonts/Times-Roman.afm');
$pdf->ezText("Daily note",$fontsize);
$pdf->ezSetMargins(0,0,260,0);
$pdf->ezSetDy(12);
$pdf->ezText("Progress note",$fontsize);
$pdf->ezSetMargins(0,0,490,0);
$pdf->ezSetDy(12);
$pdf->ezText("Discharge note",$fontsize);
$pdf->ezSetMargins(0,0,28,0);

//$pdf->selectFont('./fonts/Helvetica.afm');
$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);



$table_1 = array(array('name'=>' SOAP                                                                                                                                                                                                             ')); 
$table_2 = array(array('name'=>'<b>S:</b>')); 
$table_3 = array(array('name'=>'<b>O:</b>'));  
$table_4 = array(array('name'=>'<b>A:</b>'));  
$table_5 = array(array('name'=>'<b>P:</b>'));   
//$pdf->ezSetMargins(0,0,0,$cat_margin);
//$pdf->ezTable($table_1,array('name'=>' '),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));



$soap_name= strtoupper($soap_name);


$pdf->ezText("Name: <i>$soap_name</i>",$fontsize);
$pdf->ezText("Date: $soap_date",$fontsize);
//$pdf->ezText("Treating therapist/license#: $Thera_names",$fontsize);
$pdf->ezSetMargins(0,0,30,0);
$pdf->ezText('',$space_var);
$pdf->ezTable($table_1,array('name'=>' '),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezSetMargins(0,0,0,$cat_margin);
$pdf->ezTable($table_2,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>0));
$pdf->ezSetMargins(0,0,$sentence_margin,0);
$pdf->ezSetDy(14);
$pdf->ezText("$soap_s",$fontsize);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezSetMargins(0,0,0,$cat_margin);
$pdf->ezTable($table_3,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>0));
$pdf->ezSetMargins(0,0,$sentence_margin,0);
$pdf->ezSetDy(14);
//$pdf->ezText('',$space_var);
if(!empty($soap_O_Eval))
{
$pdf->ezText("$soap_O_Eval",$fontsize);
}
$pdf->ezText('',$space_var);
if(!empty($soap_O_M))
{
$pdf->ezText("<u><b>Modalities</b></u>: $modality. ",$fontsize);
$pdf->ezText('',$space_var);
}

if(!empty($soap_O_TS))
{

$pdf->ezText("<u><b>Therapeutic stretch:</b></u> Elongation provided to $TrSt.",$fontsize);
$pdf->ezText('',$space_var);
}
//$pdf->ezText('',$space_var);
if(!empty($soap_O_Man))
{
$pdf->ezText("<u><b>Manual</b></u>: $new_man.",$fontsize);
$pdf->ezText('',$space_var);
}
//$pdf->ezText('',$space_var);
if(!empty($soap_O_ET))
{
$pdf->ezText("<u><b>Endurance training</b></u>: $ET.",$fontsize);
$pdf->ezText('',$space_var);
}
//$pdf->ezText('',$space_var);
if(!empty($soap_O_MT))
{
$pdf->ezText("<u><b>Mobility training</b></u>: $MT.",$fontsize);
$pdf->ezText('',$space_var);
}

//$pdf->ezText('',$space_var);
if(!empty($soap_O_BT))
{
$pdf->ezText("<u><b>Balance training</b></u>: $new_bal.",$fontsize);
$pdf->ezText('',$space_var);
}

//$pdf->ezText('',$space_var);

if(!empty($soap_O_GT))
{
$pdf->ezText("<u><b>Gait training</b></u>: $gT.",$fontsize);
$pdf->ezText('',$space_var);
}

//$pdf->ezText('',$space_var);
if(!empty($soap_O_SC))
{
$pdf->ezText("<u><b>ADL's/self care</b></u>: $sC.",$fontsize);
$pdf->ezText('',$space_var);
}

//$pdf->ezText('',$space_var);
if(!empty($soap_O_SP))
{
$pdf->ezText("<u><b>Core strengthening/posture</b></u>: $sP.",$fontsize);
$pdf->ezText('',$space_var);
}

//$pdf->ezText('',$space_var);
if(!empty($soap_O_TE))
{
$pdf->ezText("<u><b>Therapeutic exercise</b></u>: $tE.",$fontsize);
$pdf->ezText('',$space_var);
}
//$pdf->ezText('',$space_var);
$pdf->ezText("<u><b>Patient educated on</b></u>: $soap_PT_edu",$fontsize);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezSetMargins(0,0,0,$cat_margin);
$pdf->ezTable($table_4,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>0));
$pdf->ezSetMargins(0,0,$sentence_margin,0);
$pdf->ezSetDy(14);
$pdf->ezText("<u><b>Existing impairments</b></u>: $eI.",$fontsize);
$pdf->ezText('',$space_var);
$pdf->ezText("<u><b>Gait deviations</b></u>: $soap_O_Gait $soap_O_Gait1 $soap_O_Gait_Box",$fontsize);
$pdf->ezText('',$space_var);
$pdf->ezText("<u><b>Rehab Potential</b></u>: $rehab_p $soap_A_RP_Box",$fontsize);

//$pdf->ezText("$rehab_p",$fontsize);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezSetMargins(0,0,0,$cat_margin);
$pdf->ezTable($table_5,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>0));
$pdf->ezSetMargins(0,0,$sentence_margin,0);
$pdf->ezSetDy(14);
$pdf->ezText("$AP $soap_A_P_Box",$fontsize);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);


$pdf->ezSetMargins(0,0,0,75);



$table_6= array(array("Evaluation"=>"","Therapeutic ex"=>$TP_ex,"Neuromuscular"=>$NM, "Manual"=>$Man, "Gait training"=>$GT,"Treatment Time"=>$TT, "Total minutes"=>$TM ));



$pdf->ezTable($table_6);

//$pdf->ezSetDy(20);
//$pdf->ezText("$Thera_names",$fontsize);



$table_test= array(array("name"=>"$Thera_names"            ));
   
                   


$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);


$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);


$pdf->ezSetMargins(0,0,300,0);

//$pdf->ezText(" $Thera_names",$fontsize);
$pdf->ezText("                                  ____________________________",10);
$pdf->ezTable($table_test,array('name'=>''),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>0));
$pdf->ezSetMargins(0,0,374,0);
//$pdf->ezText("____________________________",10);
$pdf->ezText("      Treating therapist/license#",10);
//$pdf->setColor(255,255,255);
//$pdf->line(372,130,525,130);
  
$pdf->ezSetMargins(0,0,46,0);


$pdf->ezText('',$space_var);
$pdf->ezText('',$space_var);

//$pdf->ezTable($table_sig,array('name'=>'   '),'',array('showHeadings'=>0,'shaded'=>0, 'showLines'=>1));

$pdf->ezStartPageNumbers(580,2,10,'',"Treatment# $soap_trnum ",'');

$arr=explode("/",$soap_date);
$date=$arr[2].$arr[0].$arr[1];

$pdfname = "patients/$soap_name/".$soap_name."_".$date.".pdf";
#$pdf1 =".";
#$pdf2 ="pdf";
#$pdfname =$soap_name . $pdf1 . $pdf2;
//$pdf->output();
$pdf->ezStream();
$testdir = "patients/$soap_name/";
if(!file_exists($testdir))
{
	mkdir ($testdir,   0777); 
}
$pdfcode = $pdf->ezOutput();
$fp=fopen($pdfname,'wb');
fwrite($fp,$pdfcode);
fclose($fp);
?>
