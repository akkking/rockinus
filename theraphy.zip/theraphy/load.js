var xmlHttp;

function stateChanged() 
{
	with(document.drop_list)
	{
		if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
		{
			xmlDoc=xmlHttp.responseXML;
			var str=xmlHttp.responseText;
			//str=str.substring(0,str.length-1); 
			var arr=str.split("|");
			//alert(str);
			var patient = new Array();
			patient["0"] = ["--please choose the patient--"];
			var value = folderName.value;
			patient[value]=arr;
			patientName.options.length = 0;
			var option;
			for(i = 0;i < patient[value].length;i++)
			{
				var str = patient[value][i];
				var len = str.length;
				str = str.substring(len - 12, len-4);
				len = str.length;
				var str1=str.substring(0,4);
				var str2=str.substring(4,6);
				var str3=str.substring(6,8);
				str = str2+'/'+str3+'/'+str1;
				//alert(str);
				option = new Option(str,patient[value][i]);
				patientName.options.add(option);
			}
			if(folderName.value == "0")
			 patientName.disabled = true;
			else
			 patientName.disabled = false;
		}
	}
}

function GetXmlHttpObject()
 { 
 var objXMLHttp=null
 if (window.XMLHttpRequest)
  {
  objXMLHttp=new XMLHttpRequest()
  }
 else if (window.ActiveXObject)
  {
  objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP")
  }
 return objXMLHttp
 }

 function changepatientName(str)
{
	with(document.drop_list)
	{
		xmlHttp=GetXmlHttpObject();
		if (xmlHttp==null)
		{
			alert ("Browser does not support HTTP Request");
			return;
		} 
		var url="load.php";
		url=url+"?q="+str;
		//alert(url);
		url=url+"&sid="+Math.random();
		xmlHttp.onreadystatechange=stateChanged ;
		xmlHttp.open("GET",url,true);
		xmlHttp.send(null);
   }
}

function onclickload(str)
{
	if(str=="0")
	{
		alert("please choose the patient file!");
	}
	else
	{
		//alert(str);
		url="index.php?load=";
		url=url+str;
		location.href=url;
	}
}