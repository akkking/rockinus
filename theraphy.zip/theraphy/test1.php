<form action="test2.php" method="post">
<input type="checkbox" name="soap_license[]" value= "1" />
<label>1</label> 
<input type="checkbox" name="soap_license[]" value= "2" />
<label>2</label>
<input type="checkbox" name="soap_license[]" value= "3" />
<label>3</label>
<input type="text" name="text"  />
<input type="submit" value="submit"/>
</form>