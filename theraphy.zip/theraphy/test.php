<head>
<script src="load.js"></script>
</head>
<?php  
 /*
$counter_file       =   'txt/aa.txt ';//�ļ�����·��,�ڵ�ǰĿ¼���½�aa.txt�ļ� 
$fopen                     =   fopen($counter_file,   'wb ');//�½��ļ����� 
$str="haha";
$str.="\n"."gaga2";
fputs($fopen,   $str);//���ļ���д������; 
fclose($fopen); 
 
$file = file("txt/aa.txt");
foreach($file as &$line) echo $line.'<br />';
*/

/*$str = "02/24/2012";
$arr=explode("/",$str);
echo $arr[2].$arr[0].$arr[1];*/
?>

<?php
$filenames="";
$dir = "patients/";
// Open a known directory, and proceed to read its contents
if (is_dir($dir)) {
if ($dh = opendir($dir)) {
while (($file = readdir($dh)) !== false) {
	if($file!='.'&& $file!='..')
	$filenames.="|"."$file" ;
} closedir($dh);
}
}

$filenames=substr($filenames, -(strlen($filenames)-1));

?>
<form name="drop_list">
chose the time:<select name="folderName" style= "width:170" onchange="changepatientName(this.value)">
<option value="0">--choose the date--</option>
<?php
$arr=explode("|",$filenames);
$i=0;
while($i<count($arr))
{
	?>
	<option value=<?php echo$arr[$i]; ?>>
	<?php echo $arr[$i]; ?>
	</option>
	<?php
	$i++;
}
?>
</select>
<select disabled="disabled" name="patientName" style= "width:190">
      <option>--please choose the patient--</option>
      </select>
</form>
