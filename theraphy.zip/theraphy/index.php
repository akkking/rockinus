<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> Progress Note </title>
<link href="css/calendar.css" rel="stylesheet">
<script src="js/calendar.js"></script>
<script src="load.js"></script>
<style type="text/css">
body {
	background: #f0f0f0;
	margin: 0;
	padding: 0;
	font: 10px normal Verdana, Arial, Helvetica, sans-serif;
	color: #444;
	font-size: 1.0em;
}
h1 {font-size: 3em; margin: 20px 0;}
.container {width: 1050px; height: 1000px; margin: 10px auto;}
ul.tabs {
	margin: 0;
	padding: 0;
	float: left;
	list-style: none;
	height: 64px;
	border-bottom: 1px solid #999;
	border-left: 1px solid #999;
	width: 100%;
	font-size: 8.5px;
}
ul.tabs li {
	float: left;
	margin: 0;
	padding: 0;
	height: 31px;
	line-height: 31px;
	border: 1px solid #999;
	border-left: none;
	margin-bottom: -1px;
	background: #e0e0e0;
	overflow: hidden;
	position: relative;
}
ul.tabs li a {
	text-decoration: none;
	color: #000;
	display: block;
	font-size: 1.2em;
	padding: 0 20px;
	border: 1px solid #fff;
	outline: none;
}
ul.tabs li a:hover {
	background: #09F;
}	
html ul.tabs li.active, html ul.tabs li.active a:hover  {
	background: #09F;
	border-bottom: 1px solid #fff;
}
.tab_container {
	border: 1px solid #999;
	border-top: none;
	clear: both;
	float: left; 
	width: 100%;
	background: #fff;
	-moz-border-radius-bottomright: 5px;
	-khtml-border-radius-bottomright: 5px;
	-webkit-border-bottom-right-radius: 5px;
	-moz-border-radius-bottomleft: 5px;
	-khtml-border-radius-bottomleft: 5px;
	-webkit-border-bottom-left-radius: 5px;
}
.tab_content {
	padding: 20px;
	font-size: 10px;
}
.tab_content h2 {
	font-weight: normal;
	padding-bottom: 10px;
	border-bottom: 1px dashed #ddd;
	font-size: 1.8em;
}
.tab_content h3 a{
	color: #254588;
}
.tab_content img {
	float: left;
	margin: 0 20px 20px 0;
	border: 1px solid #ddd;
	padding: 5px;
}
</style>

<style>
#container {
	width: 1100px;
	/* [disabled]padding: 25px; */
	padding-bottom: 60px;
	/* [disabled]padding-right: 10px; */
}
.holder {
	float: left;
	width: 300px;
	padding-right: 10px;
	padding-top: 2.5px;
	margin-top: 5px;
	margin-bottom: 5px;
	padding-left: 10px;
	margin-right: 0px;
	margin-left: 15px;
	font-size: 1.2em;
}

.holder1 {
	float: left;
	width: 500px;
	padding-right: 10px;
	padding-top: 2.5px;
	margin-top: 5px;
	margin-bottom: 5px;
	padding-left: 10px;
	margin-right: 0px;
	margin-left: 15px;
	font-size: 1.2em;
}

</style>

<script type="text/javascript"
src="js/jquery.min.js"></script>

<script type="text/javascript">


$(document).ready(function() {

	//Default Action
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content
	
	//On Click Event
	$("ul.tabs li").click(function() {
		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		if(activeTab=="#tab17")
		{
			//alert(activeTab);
		}
		$(activeTab).fadeIn(); //Fade in the active content
		return false;
	});

});
</script>
</head>

<body>
<?php
if(isset($_GET['load']))
{
	$filename=$_GET['load'];
	//echo $filename;
	$patientname=substr($filename,0,-13);
	//echo $patientname;
	$date=substr($filename,-12,8);
	//echo $date;
	$filename=substr($filename,0,-4);
	//echo $filename;
	$filename.=".txt";
	//echo $filename;
	$file = fopen("txt/$patientname/$filename","r");
	?>
	<form name="drop_list" action="process_form.php" method="post" >

<div class="container">
<h3>Righteous Rehab Inc. dba TOP Physical Therapy</h3>
    <ul class="tabs">
        <li><a href="#tab1">pt. info</a></li>
        <li><a href="#tab2">S:</a></li>
        <li><a href="#tab3">O: ADL's/educ</a></li>
        <li><a href="#tab4">O: Balance training</a></li>
        <li><a href="#tab5">O: Core ex/posture</a></li>
        <li><a href="#tab6">O: Endurance training</a></li>
         <li><a href="#tab7">O: Gait training</a></li>
         <li><a href="#tab8">O: Manual</a></li>
         <li><a href="#tab9">O: Modalities</a></li>
         <li><a href="#tab10">O: Mobility training</a></li>
         <li><a href="#tab11">O: Therapeutic stretch</a></li>   
        <li><a href="#tab12">O:  Ther ex</a></li>
        <li><a href="#tab13">A: Existing impairments</a></li>
        
        <li><a href="#tab14">A: Gait deviations</a></li>
          
          
          <li><a href="#tab15">A: Rehab Potential:</a></li>
         
        
        
        <li><a href="#tab16">P:</a></li>
        <li><a href="#tab17">billing/save:</a></li>
		<!--<li><a href="#tab18">view/load:</a></li>-->
    </ul>
    <div class="tab_container">
    
    <div id="tab1" class="tab_content">
            <h2>Patient Info:</h2>
            <p>
			<?php
			if(! feof($file))
			{
				$buff = fgets($file);
				if($buff=="Daily Note\n")
				{?>
					<input type="checkbox" name="checkmark1" value= "Daily Note" checked="true"/>
                <label>Daily Note</label>
				<?php
				}
				else
				{?>
					<input type="checkbox" name="checkmark1" value= "Daily Note" />
                <label>Daily Note</label>
				<?php
				}
			}
			?>
			
			<?php
			if(! feof($file))
			{
				$buff = fgets($file);
				if($buff=="Progress Note\n")
				{
				?>
					<input type="checkbox" name="checkmark2" value= "Progress Note" checked="true"/>
                <label>Progress Note</label>
				<?php
				}
				else
				{?>
					<input type="checkbox" name="checkmark2" value= "Progress Note" />
                <label>Progress Note</label>
				<?php
				}
			}
			?>
			
			<?php
			if(! feof($file))
			{
				$buff = fgets($file);
				if($buff=="Discharge Note\n")
				{
				?>
					<input type="checkbox" name="checkmark3" value= "Discharge Note" checked="true"/>
                <label>Discharge Note</label>
				<?php
				}
				else
				{?>
					<input type="checkbox" name="checkmark3" value= "Discharge Note" />
                <label>Discharge Note</label>
				<?php
				}
			}
			?>
              
      <p>                                          
      <p>Name:
	  <?php
	  if(! feof($file))
	  {
	  	$buff = fgets($file);
		?>
		<input name="soap_name" type="text" id="sub_text" value=<?php echo $buff; ?> size="50" />
		<?php
	  }
	  ?>
                
      <p>Date:
	  <?php
	  if(! feof($file))
	  {
	  	$buff = fgets($file);
		?>
		<input type="text" class="calendarSelectDate" name="soap_date" value=<?php echo $buff; ?> />
		<?php
	  }
	  ?>
	                        
      <p>Treatment#: 
	  <?php
	  if(! feof($file))
	  {
	  	$buff = fgets($file);
		if($buff=="\n")
		{
		?>
		<input type="text" name="soap_trnum" value="" /> 
		<?php
		}
		else
		{
		?>
		<input type="text" name="soap_trnum" value="<?php echo $buff; ?>" /> 
		<?php
		}
	  }
	  ?>
	           
                      
      <p>Treating therapist/license#:
	  <?php
	  if(! feof($file))
	  {
	  	$buff = fgets($file);
		$arr=explode("|",$buff);
		
		$i=0;
		while($i<count($arr))
		{
			if(($arr[$i]=="Maxine Hurley PT 21823")||($arr[$i]=="Maxine Hurley PT 21823\n"))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Maxine Hurley PT 21823" checked="true"/>
                <label>Maxine Hurley PT 21823</label> 
			<?php
				break;
			}
			$i++;
			if($i==count($arr))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Maxine Hurley PT 21823" />
                <label>Maxine Hurley PT 21823</label>
			<?php
			}
		}
		
		$i=0;
		while($i<count($arr))
		{
			if(($arr[$i]=="Maxine Hurley PT 21823")||($arr[$i]=="Maxine Hurley PT 21823\n"))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Zebulon Gardner PTA 12528" checked="true"/>
                <label>Zebulon Gardner PTA 12528</label> 
			<?php
				break;
			}
			$i++;
			if($i==count($arr))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Zebulon Gardner PTA 12528" />
                <label>Zebulon Gardner PTA 12528</label>
			<?php
			}
		}
		
		$i=0;
		while($i<count($arr))
		{
			if(($arr[$i]=="Steven Safdia PTA 14630 ")||($arr[$i]=="Steven Safdia PTA 14630 \n"))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Steven Safdia PTA 14630 " checked="true"/>
                <label>Steven Safdia PTA 14630 </label>
			<?php
				break;
			}
			$i++;
			if($i==count($arr))
			{
			?>
				<input type="checkbox" name="soap_license[]" value= "Steven Safdia PTA 14630 " />
                <label>Steven Safdia PTA 14630 </label>
			<?php
			}
		}
	  }
	  ?>
	  
                      
                                       
                  
                      
            
      </div>
            
            <div id="tab2" class="tab_content">
            <h2>S:</h2>
            
             <p> <stong>S:</stong>
			 
			 <?php
			 if(! feof($file))
			 {
				$buff = fgets($file);
				while(!feof($file))
				{
					if($buff=="...\n")
					{
					?>
					<textarea style="color: red; background-color: lightyellow" name="soap_s" cols="100" rows="4"  ></textarea>
					<?php
					break;
					}
					$nextline=fgets($file);
					//get the content from text file untill the "..." shows up
					if($nextline=="...\n")
					{
					?>
					<textarea style="color: red; background-color: lightyellow" name="soap_s" cols="100" rows="4"  ><?php echo $buff; ?></textarea>
					<?php
					break;
					}
					$buff.=$nextline;
				}
			 }
			 ?>
                 
              </p>
               <p> <stong></stong>              
               <p></div>
               
               
                <div id="tab3" class="tab_content">
 <h2>O:</h2>
            
             <p>
			 <?php
			 if(! feof($file))
			 {
				$buff = fgets($file);
				if(($buff=="Patient evaluated today, refer to evaluation for objective findings.")
				||($buff=="Patient evaluated today, refer to evaluation for objective findings.\n"))
				{
				?>
				<input type="checkbox" name="soap_O_Eval" value= "Patient evaluated today, refer to evaluation for objective findings." checked="true"/>
				<?php
				}
				else
				{
				?>
					<input type="checkbox" name="soap_O_Eval" value= "Patient evaluated today, refer to evaluation for objective findings." />
				<?php
				}
			 }
			 ?>
              
              <label>Patient evaluated today, refer to evaluation for objective findings.</label>
              </p>
             <p>&nbsp;</p>
            
            <h3>ADL's/educ:</h3>
            
            <p>
   
            
            <div id = "container">
			<?php
			if(! feof($file))
			{
				$buff = fgets($file);
				$arr=explode("|",$buff);
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="buttoning/fastening/zippering")||($arr[$i]=="buttoning/fastening/zippering\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "buttoning/fastening/zippering" checked="true"/>
						<label>buttoning/fastening/zippering</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "buttoning/fastening/zippering" />
						<label>buttoning/fastening/zippering</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="upper/lower body dressing")||($arr[$i]=="upper/lower body dressing\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body dressing" checked="true"/>
						<label>upper/lower body dressing</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body dressing" />
						<label>upper/lower body dressing</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="donning/doffing socks/shoes")||($arr[$i]=="donning/doffing socks/shoes\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "donning/doffing socks/shoes" checked="true"/>
						<label>donning/doffing socks/shoes</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "donning/doffing socks/shoes" />
						<label>donning/doffing socks/shoes</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="bend-lift & carry exercise")||($arr[$i]=="bend-lift & carry exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "bend-lift & carry exercise" checked="true"/>
						<label>bend-lift & carry exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "bend-lift & carry exercise" />
						<label>bend-lift & carry exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="toileting safety")||($arr[$i]=="toileting safety\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "toileting safety" checked="true"/>
						<label>toileting safety</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "toileting safety" />
						<label>toileting safety</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="simulated laundry & grocery")||($arr[$i]=="simulated laundry & grocery\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "simulated laundry & grocery" checked="true"/>
						<label>simulated laundry & grocery</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "simulated laundry & grocery" />
						<label>simulated laundry & grocery</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="upper/lower body grooming")||($arr[$i]=="upper/lower body grooming\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body grooming" checked="true"/>
						<label>upper/lower body grooming</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body grooming" />
						<label>upper/lower body grooming</label> </div>
					<?php
					}
				}
				
			}
			?>




<div class = "holder"></div>
<div class = "holder"></div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class = "holder"><h3> *Patient educated on:</h3> <textarea style="color: red; background-color: lightyellow" name="soap_PT_edu" cols="100" rows="4"  >
<?php
	if(! feof($file))
	{
		$buff = fgets($file);
		//get the content from text file untill the "..." shows up
		while(! feof($file))
		{
			if($buff=="...\n")
			{
				break;
			}
			$nextline=fgets($file);
			if($nextline=="...\n")
			{
				echo $buff;
				break;
			}
			$buff.=$nextline;
		}
	}
?>
</textarea> </div></div>            
            
            </div> 
            

            
      <div id="tab4" class="tab_content">
    <h2>&nbsp;</h2>
    <h2>O:</h2>
            <h3>Balance training:</h3>
            
        <div id = "container">
		
		<?php
			if(! feof($file))
			{
				$buff = fgets($file);
				$arr=explode("|",$buff);
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="recovery during mobility")||($arr[$i]=="recovery during mobility\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "recovery during mobility" checked="true"/>
						<label>Balance recovery during mobility</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "recovery during mobility" />
						<label>Balance recovery during mobility</label> </div>
					<?php
					}
				}
				
				$buff = fgets($file);
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="bend-lift & carry exercise")||($arr[$i]=="bend-lift & carry exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "bend-lift & carry exercise" checked="true"/>
						<label>bend-lift & carry exercise</label>
						<label>lbs</label> 
						<input name="soap_O_BT_box" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="8" /> 
						</div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "bend-lift & carry exercise" />
						<label>bend-lift & carry exercise</label>
						<input name="soap_O_BT_box" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="8" />
						<label>lbs</label> </div> 
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="Wii (for balance, endurance & strength)")||($arr[$i]=="Wii (for balance, endurance & strength)\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Wii (for balance, endurance & strength)" checked="true"/>
						<label>Wii (for balance, endurance & strength)</label> </div>
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Wii (for balance, endurance & strength)" />
						<label>Wii (for balance, endurance & strength)</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="standing static/dynamic exercise")||($arr[$i]=="standing static/dynamic exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "standing static/dynamic exercise" checked="true"/>
						<label>standing static/dynamic exercise</label> </div>
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "standing static/dynamic exercise" />
						<label>standing static/dynamic exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="equilibrium challenging  training")||($arr[$i]=="equilibrium challenging  training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "equilibrium challenging  training" checked="true"/>
						<label>equilibrium challenging  training</label> </div>
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "equilibrium challenging  training" />
						<label>equilibrium challenging  training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="weight shifting ex")||($arr[$i]=="weight shifting ex\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "weight shifting ex" checked="true"/>
						<label>weight shifting ex</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "weight shifting ex" />
						<label>weight shifting ex</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="sitting static/dynamic exercise")||($arr[$i]=="sitting static/dynamic exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "sitting static/dynamic exercise" checked="true"/>
						<label>sitting static/dynamic exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "sitting static/dynamic exercise" />
						<label>sitting static/dynamic exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="ankle/hip strategy")||($arr[$i]=="ankle/hip strategy\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "ankle/hip strategy" checked="true"/>
						<label>ankle/hip strategy</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "ankle/hip strategy" />
						<label>ankle/hip strategy</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="vestibular training")||($arr[$i]=="vestibular training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular training" checked="true"/>
						<label>vestibular training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular training" />
						<label>vestibular training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="vertigo ex")||($arr[$i]=="vertigo ex\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vertigo ex" checked="true"/>
						<label>vertigo ex</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vertigo ex" />
						<label>vertigo ex</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="obstacle negotiation")||($arr[$i]=="obstacle negotiation\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "obstacle negotiation" checked="true"/>
						<label>obstacle negotiation</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "obstacle negotiation" />
						<label>obstacle negotiation</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="fall recovery training")||($arr[$i]=="fall recovery training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "fall recovery training" checked="true"/>
						<label>fall recovery training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "fall recovery training" />
						<label>fall recovery training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="movement across midline")||($arr[$i]=="movement across midline\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement across midline" checked="true"/>
						<label>movement across midline</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement across midline" />
						<label>movement across midline</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="single leg stance")||($arr[$i]=="single leg stance\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "single leg stance" checked="true"/>
						<label>single leg stance</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "single leg stance" />
						<label>single leg stance</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="Bobath")||($arr[$i]=="Bobath\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Bobath" checked="true"/>
						<label>Bobath</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Bobath" />
						<label>Bobath</label> </div>
					<?php
					}
				}
				
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="wobble board")||($arr[$i]=="wobble board\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "wobble board" checked="true"/>
						<label>wobble board</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "wobble board" />
						<label>wobble board</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="balance beam")||($arr[$i]=="balance beam\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "balance beam" checked="true"/>
						<label>balance beam</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "balance beam" />
						<label>balance beam</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="vestibular rocker board")||($arr[$i]=="vestibular rocker board\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular rocker board" checked="true"/>
						<label>vestibular rocker board</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular rocker board" />
						<label>vestibular rocker board</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="vestibular balance disc/wedges")||($arr[$i]=="vestibular balance disc/wedges\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular balance disc/wedges" checked="true"/>
						<label>vestibular balance disc/wedges</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular balance disc/wedges" />
						<label>vestibular balance disc/wedges</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="movement of COG over BOS training")||($arr[$i]=="movement of COG over BOS training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement of COG over BOS training" checked="true"/>
						<label>movement of COG over BOS training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement of COG over BOS training" />
						<label>movement of COG over BOS training</label> </div>
					<?php
					}
				}
				
				
			}
			?>
		
		



</div> 
    
</div>
            
       
       
                  
 <div id="tab5" class="tab_content">
 <h2>O:</h2>
            <h3>Core strengthening/posture:</h3>
            
      <div id = "container">
	  <?php
	  		if(! feof($file))
			{
				$buff = fgets($file);
				$arr=explode("|",$buff);
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="lumbar stabilization")||($arr[$i]=="lumbar stabilization\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar stabilization" checked="true"/>
						<label>lumbar stabilization</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar stabilization" />
						<label>lumbar stabilization</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="lumbar mobility")||($arr[$i]=="lumbar mobility\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar mobility" checked="true"/>
						<label>lumbar mobility</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar mobility" />
						<label>lumbar mobility</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="postural awareness")||($arr[$i]=="postural awareness\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "postural awareness" checked="true"/>
						<label>postural awareness</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "postural awareness" />
						<label>postural awareness</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="strengthening exercise")||($arr[$i]=="strengthening exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "strengthening exercise" checked="true"/>
						<label>strengthening exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "strengthening exercise" />
						<label>strengthening exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="body mechanics")||($arr[$i]=="body mechanics\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "body mechanics" checked="true"/>
						<label>body mechanics</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "body mechanics" />
						<label>body mechanics</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="back protection technique")||($arr[$i]=="back protection technique\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "back protection technique" checked="true"/>
						<label>back protection technique</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "back protection technique" />
						<label>back protection technique</label> </div>
					<?php
					}
				}
				
			}
	  ?>




</div> 

</div>
       
            
            
            
            <div id="tab6" class="tab_content">
        <h2>O:</h2>
            <h3>Endurance training:</h3>
<div id = "container">
              <!--  <div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "endurance training" />
<label>endurance training</label> </div> -->
<?php
	  		if(! feof($file))
			{
				$buff = fgets($file);
				$arr=explode("|",$buff);
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="breathing exercise")||($arr[$i]=="breathing exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "breathing exercise" checked="true"/>
						<label>breathing exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "breathing exercise" />
						<label>breathing exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="diaphragmatic breathing exercise")||($arr[$i]=="diaphragmatic breathing exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "diaphragmatic breathing exercise" checked="true"/>
						<label>diaphragmatic breathing exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "diaphragmatic breathing exercise" />
						<label>diaphragmatic breathing exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="pursed lip breathing exercise")||($arr[$i]=="pursed lip breathing exercise\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "postural awareness" checked="true"/>
						<label>pursed lip breathing exercise</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "pursed lip breathing exercise" />
						<label>pursed lip breathing exercise</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="bike ")||($arr[$i]=="bike \n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "bike " checked="true"/>
						<label>bike</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "bike " />
						<label>bike</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="Nu step ")||($arr[$i]=="Nu step \n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Nu step " checked="true"/>
						<label>Nu step</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Nu step " />
						<label>Nu step</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="treadmill")||($arr[$i]=="treadmill\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "treadmill" checked="true"/>
						<label>treadmill</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "treadmill" />
						<label>treadmill</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="incentive spirometer")||($arr[$i]=="incentive spirometer\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "incentive spirometer" checked="true"/>
						<label>incentive spirometer</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "incentive spirometer" />
						<label>incentive spirometer</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="UBE")||($arr[$i]=="UBE\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "UBE" checked="true"/>
						<label>UBE</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "UBE" />
						<label>UBE</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="Wii fitness training")||($arr[$i]=="Wii fitness training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Wii fitness training" checked="true"/>
						<label>Wii fitness training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Wii fitness training" />
						<label>Wii fitness training</label> </div>
					<?php
					}
				}
				
			}
	  ?>

	</div> 
</div>
            
            
            
                
 <div id="tab7" class="tab_content">
 <h2>O:</h2>
            <h3>Gait training:</h3>
            
      <div id = "container">
<?php
	  		if(! feof($file))
			{
				$buff = fgets($file);
				$arr=explode("|",$buff);
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="braiding")||($arr[$i]=="braiding\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "braiding" checked="true"/>
						<label>braiding</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "braiding" />
						<label>braiding</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="tandem walking")||($arr[$i]=="tandem walking\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tandem walking" checked="true"/>
						<label>tandem walking</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tandem walking" />
						<label>tandem walking</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="outdoor ambulation")||($arr[$i]=="outdoor ambulation\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "outdoor ambulation" checked="true"/>
						<label>outdoor ambulation</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "outdoor ambulation" />
						<label>outdoor ambulation</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="curb training")||($arr[$i]=="curb training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "curb training" checked="true"/>
						<label>curb training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "curb training" />
						<label>curb training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="stair training")||($arr[$i]=="stair training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "stair training" checked="true"/>
						<label>stair training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "stair training" />
						<label>stair training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="gait training w/o assistive device")||($arr[$i]=="gait training w/o assistive device\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training w/o assistive device" checked="true"/>
						<label>gait training w/o assistive device</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training w/o assistive device" />
						<label>gait training w/o assistive device</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="gait training with prosthesis")||($arr[$i]=="gait training with prosthesis\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training with prosthesis" checked="true"/>
						<label>gait training with prosthesis</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training with prosthesis" />
						<label>gait training with prosthesis</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="tilt table")||($arr[$i]=="tilt table\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tilt table" checked="true"/>
						<label>tilt table</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tilt table" />
						<label>tilt table</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="standing training")||($arr[$i]=="standing training\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "standing training" checked="true"/>
						<label>standing training</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "standing training" />
						<label>standing training</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="side stepping")||($arr[$i]=="side stepping\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "side stepping" checked="true"/>
						<label>side stepping</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "side stepping" />
						<label>side stepping</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="marching")||($arr[$i]=="marching\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "marching" checked="true"/>
						<label>marching</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "marching" />
						<label>marching</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="walking with resistance")||($arr[$i]=="walking with resistance\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking with resistance" checked="true"/>
						<label>walking with resistance</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking with resistance" />
						<label>walking with resistance</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="walking backwards")||($arr[$i]=="walking backwards\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking backwards" checked="true"/>
						<label>walking backwards</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking backwards" />
						<label>walking backwards</label> </div>
					<?php
					}
				}
				
				$i=0;
				while($i<count($arr))
				{
					if(($arr[$i]=="treadmill")||($arr[$i]=="treadmill\n"))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "treadmill" checked="true"/>
						<label>treadmill</label> </div> 
					<?php
						break;
					}
					$i++;
					if($i==count($arr))
					{
					?>
						<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "treadmill" />
						<label>treadmill</label> </div>
					<?php
					}
				}
				
			}
?>





	</div>   
</div>
            
    
    
    
    <div id="tab8" class="tab_content">
        <h2>O:</h2>
            <h3>Manual:</h3>
<div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	?>
	
	<div class = "holder">
	<?php
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="joint mobs of")||($arr[$i]=="joint mobs of\n"))
		{
		?>
			<input type="checkbox" name="soap_O_Man[]" value= "joint mobs of" checked="true"/>
			<label>joint mobs of</label> 
			<input name="soap_O_Man_box" type="text" id="sub_text2" size="15" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>"/>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<input type="checkbox" name="soap_O_Man[]" value= "joint mobs of" />
			<label>joint mobs of</label>
			<input name="soap_O_Man_box" type="text" id="sub_text2" size="15" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>"/>
		<?php
		}
	}
	?>
	</div>
	
	<?php
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="manual lymph drainage")||($arr[$i]=="manual lymph drainage\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual lymph drainage" checked="true"/>
			<label>manual lymph drainage</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual lymph drainage" />
			<label>manual lymph drainage</label> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="manual traction to")||($arr[$i]=="manual traction to\n"))
		{
		?>
		  <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual traction to" checked="true"/>
			<label>manual traction to</label>
			<input name="soap_O_Man_box22" type="text" id="soap_O_Man_box2" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" />
			</div>
			<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual traction to" />
			<label>manual traction to</label> <input name="soap_O_Man_box2" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="taping")||($arr[$i]=="taping\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "taping" checked="true"/>
			<label>taping</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "taping" />
			<label>taping</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="stump wrapping")||($arr[$i]=="stump wrapping\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump wrapping" checked="true"/>
			<label>stump wrapping</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump wrapping" />
			<label>stump wrapping</label> </div>
		<?php
		}
	}
	
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="stump care")||($arr[$i]=="stump care\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump care" checked="true"/>
			<label>stump care</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump care" />
			<label>stump care</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="chest physical therapy")||($arr[$i]=="chest physical therapy\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "chest physical therapy" checked="true"/>
			<label>chest physical therapy</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "chest physical therapy" />
			<label>chest physical therapy</label> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="chest physical therapy")||($arr[$i]=="chest physical therapy\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "massage to" checked="true"/>
             <label>massage to</label><input name="soap_O_Man_box3" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "massage to" />
             <label>massage to</label><input name="soap_O_Man_box3" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="myofascial release")||($arr[$i]=="myofascial release\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "myofascial release" checked="true"/>
			<label>myofascial release</label> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "myofascial release" />
			<label>myofascial release</label> </div>
		<?php
		}
	}
	
}

?>

        </div>             
      </div>
            
            
<div id="tab9" class="tab_content">
            <h2>O:</h2>
           
            
            <h3>&nbsp;</h3>
            <p>&nbsp;</p>
            <h3>Modalities:</h3>
            
<div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="ultrasound to")||($arr[$i]=="ultrasound to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ultrasound to" checked="true"/>
                <label>ultrasound to</label><input name="soap_O_M_box" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
		  <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ultrasound to" />
                <label>ultrasound to</label>
                <input name="soap_O_M_box10" type="text" id="soap_O_M_box" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" />
		  </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="electrical stimulation to")||($arr[$i]=="electrical stimulation to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "electrical stimulation to" checked="true"/>
       <label>electrical stimulation to</label><input name="soap_O_M_box2" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "electrical stimulation to" />
                <label>electrical stimulation to</label><input name="soap_O_M_box2" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="anodyne to")||($arr[$i]=="anodyne to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "anodyne to" checked="true"/>
                <label>anodyne to</label><input name="soap_O_M_box3" type="text" id="sub_text" vvalue="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "anodyne to" />
                <label>anodyne to</label><input name="soap_O_M_box3" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="ETPS to")||($arr[$i]=="ETPS to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ETPS to" checked="true"/>
                <label>ETPS to</label><input name="soap_O_M_box4" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ETPS to" />
                <label>ETPS to</label><input name="soap_O_M_box4" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="cold laser to")||($arr[$i]=="cold laser to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold laser to" checked="true"/>
                <label>cold laser to</label><input name="soap_O_M_box5" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold laser to" />
                <label>cold laser to</label><input name="soap_O_M_box5" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="moist heat to")||($arr[$i]=="moist heat to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "moist heat to" checked="true"/>
                <label>moist heat to</label><input name="soap_O_M_box6" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "moist heat to" />
                <label>moist heat to</label><input name="soap_O_M_box6" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="cold pack to")||($arr[$i]=="cold pack to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold pack to" checked="true"/>
                <label>cold pack to</label><input name="soap_O_M_box7" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold pack to" />
                <label>cold pack to</label><input name="soap_O_M_box7" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="contrast bath")||($arr[$i]=="contrast bath\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "contrast bath" checked="true"/>
			<label>contrast bath</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "contrast bath" />
                <label>contrast bath</label> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="iontophoresis to")||($arr[$i]=="iontophoresis to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "iontophoresis to" checked="true"/>
                <label>iontophoresis to</label><input name="soap_O_M_box8" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "iontophoresis to" />
                <label>iontophoresis to</label><input name="soap_O_M_box8" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	$buff = fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="phonophoresis to")||($arr[$i]=="phonophoresis to\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "phonophoresis to" checked="true"/>
                <label>phonophoresis to</label><input name="soap_O_M_box9" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "phonophoresis to" />
                <label>phonophoresis to</label><input name="soap_O_M_box9" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="biofeedback")||($arr[$i]=="biofeedback\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "biofeedback" checked="true"/>
                <label>biofeedback</label></div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "biofeedback" />
                <label>biofeedback</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="paraffin")||($arr[$i]=="paraffin\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "paraffin" checked="true"/>
                <label>paraffin</label></div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "paraffin" />
                <label>paraffin</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="medi cupping massage")||($arr[$i]=="medi cupping massage\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "medi cupping massage" checked="true"/>
                <label>medi cupping massage</label></div> 
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "medi cupping massage" />
                <label>medi cupping massage</label></div>
		<?php
		}
	}
	
}
?> 
               
</div>                 
                

   </div>
        
        
        
         <div id="tab10" class="tab_content">
         <h2>O:</h2>
            <h3>Mobility training:</h3>
            
           <div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="transfer training")||($arr[$i]=="transfer training\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "transfer training" checked="true" />
			<label>transfer training</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "transfer training" />
			<label>transfer training</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="car transfer training")||($arr[$i]=="car transfer training\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "car transfer training" checked="true" />
			<label>car transfer training</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "car transfer training" />
			<label>car transfer training</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="bed mobility training")||($arr[$i]=="bed mobility training\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bed mobility training" checked="true" />
			<label>bed mobility training</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bed mobility training" />
			<label>bed mobility training</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="sliding board transfer")||($arr[$i]=="sliding board transfer\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sliding board transfer" checked="true" />
			<label>sliding board transfer</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sliding board transfer" />
			<label>sliding board transfer</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="bathtub/shower transfer training")||($arr[$i]=="bathtub/shower transfer training\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bathtub/shower transfer training" checked="true" />
			<label>bathtub/shower transfer training</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bathtub/shower transfer training" />
			<label>bathtub/shower transfer training</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="practice getting up from fall")||($arr[$i]=="practice getting up from fall\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "practice getting up from fall" checked="true" />
			<label>practice getting up from fall</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "practice getting up from fall" />
			<label>practice getting up from fall</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="wheelchair training")||($arr[$i]=="wheelchair training\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "wheelchair training" checked="true" />
			<label>wheelchair training</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "wheelchair training" />
			<label>wheelchair training</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="sit to stand exercises")||($arr[$i]=="sit to stand exercises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sit to stand exercises" checked="true" />
			<label>sit to stand exercises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sit to stand exercises" />
			<label>sit to stand exercises</label> </div>
		<?php
		}
	}
}
?>


</div> 
        
</div>
    


 
            
            
            <div id="tab11" class="tab_content">
        <h2>O:</h2>
<h3>Therapeutic stretch: elongation provided to</h3>
<div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hamstrings")||($arr[$i]=="hamstrings\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hamstrings" checked="true" />
			<label>hamstrings</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hamstrings" />
             <label>hamstrings</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="quads")||($arr[$i]=="quads\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "quads" checked="true" />
			<label>quads</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "quads" />
             <label>quads</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="piriformis")||($arr[$i]=="piriformis\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "piriformis" checked="true" />
			<label>piriformis</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "piriformis" />
             <label>piriformis</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Cervical spine/upper traps stretches")||($arr[$i]=="Cervical spine/upper traps stretches\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "Cervical spine/upper traps stretches" checked="true" />
			<label>Cervical spine/upper traps stretches</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "Cervical spine/upper traps stretches" />
             <label>Cervical spine/upper traps stretches</label></div>
		<?php
		}
	}
	
	$i=0;
	$buff=fgets($file);
	while($i<count($arr))
	{
		if(($arr[$i]=="traction of")||($arr[$i]=="traction of\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "traction of" checked="true" />
			<label>traction of</label><input name="soap_O_TS_box" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /></div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "traction of" />
             <label>traction of</label><input name="soap_O_TS_box" type="text" id="sub_text" value="<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="15" /></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="l/s paraspinals")||($arr[$i]=="l/s paraspinals\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "l/s paraspinals" checked="true" />
			<label>l/s paraspinals</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "l/s paraspinals" />
             <label>l/s paraspinals</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="carpal tunnel")||($arr[$i]=="carpal tunnel\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "carpal tunnel" checked="true" />
			<label>carpal tunnel</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "carpal tunnel" />
             <label>carpal tunnel</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="gastro-soleus complex")||($arr[$i]=="gastro-soleus complex\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "gastro-soleus complex" checked="true" />
			<label>gastro-soleus complex</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "gastro-soleus complex" />
             <label>gastro-soleus complex</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip ERs")||($arr[$i]=="hip ERs\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip ERs" checked="true" />
			<label>hip ERs</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip ERs" />
             <label>hip ERs</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip IRs")||($arr[$i]=="hip IRs\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip IRs" checked="true" />
			<label>hip IRs</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip IRs" />
             <label>hip IRs</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip abductors")||($arr[$i]=="hip abductors\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip abductors" checked="true" />
			<label>hip abductors</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip abductors" />
             <label>hip abductors</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip adductors")||($arr[$i]=="hip adductors\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip adductors" checked="true" />
			<label>hip adductors</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip adductors" />
             <label>hip adductors</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="supinators")||($arr[$i]=="supinators\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "supinators" checked="true" />
			<label>supinators</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "supinators" />
             <label>supinators</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="pronators")||($arr[$i]=="pronators\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "pronators" checked="true" />
			<label>pronators</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "pronators" />
             <label>pronators</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="upper traps")||($arr[$i]=="upper traps\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "upper traps" checked="true" />
			<label>upper traps</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "upper traps" />
             <label>upper traps</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="shoulder IRs")||($arr[$i]=="shoulder IRs\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder IRs" checked="true" />
			<label>shoulder IRs</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder IRs" />
             <label>shoulder IRs</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="shoulder ERs")||($arr[$i]=="shoulder ERs\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder ERs" checked="true" />
			<label>shoulder ERs</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder ERs" />
             <label>shoulder ERs</label></div>
		<?php
		}
	}
	

	
}
?>
</div> 
    
</div>
            
            
            
            
  <div id="tab12" class="tab_content">
  <h2>O:</h2>
            <h3>Therapeutic exercise:</h3>

            <div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="resistive exercise")||($arr[$i]=="resistive exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "resistive exercise" checked="true" />
			<label>resistive exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "resistive exercise" />
             <label>resistive exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="open chain exercise")||($arr[$i]=="open chain exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "open chain exercise" checked="true" />
			<label>open chain exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "open chain exercise" />
             <label>open chain exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="close chain exercise")||($arr[$i]=="close chain exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "close chain exercise" checked="true" />
			<label>close chain exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "close chain exercise" />
             <label>close chain exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Proprioceptive Neuromuscular Facilitation")||($arr[$i]=="Proprioceptive Neuromuscular Facilitation\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Proprioceptive Neuromuscular Facilitation" checked="true" />
			<label>Proprioceptive Neuromuscular Facilitation</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Proprioceptive Neuromuscular Facilitation" />
             <label>Proprioceptive Neuromuscular Facilitation</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="contract/relax technique")||($arr[$i]=="contract/relax technique\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "contract/relax technique" checked="true" />
			<label>contract/relax technique</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "contract/relax technique" />
             <label>contract/relax technique</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="gravity eliminated exercise")||($arr[$i]=="gravity eliminated exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity eliminated exercise" checked="true" />
			<label>gravity eliminated exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity eliminated exercise" />
             <label>gravity eliminated exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="gravity assistive exercise")||($arr[$i]=="gravity assistive exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity assistive exercise" checked="true" />
			<label>gravity assistive exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity assistive exercise" />
             <label>gravity assistive exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="isokinetics")||($arr[$i]=="isokinetics\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isokinetics" checked="true" />
			<label>isokinetics</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isokinetics" />
             <label>isokinetics</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="therapeutic exercise w/gym ball")||($arr[$i]=="therapeutic exercise w/gym ball\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "therapeutic exercise w/gym ball" checked="true" />
			<label>therapeutic exercise w/gym ball</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "therapeutic exercise w/gym ball" />
             <label>therapeutic exercise w/gym ball</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="thera-band exercises")||($arr[$i]=="thera-band exercises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "thera-band exercises" checked="true" />
			<label>thera-band exercises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "thera-band exercises" />
             <label>thera-band exercises</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="treadmill")||($arr[$i]=="treadmill\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "treadmill" checked="true" />
			<label>treadmill</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "treadmill" />
             <label>treadmill</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="bike")||($arr[$i]=="bike\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bike" checked="true" />
			<label>bike</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bike" />
             <label>bike</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Nu-step")||($arr[$i]=="Nu-step\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Nu-step" checked="true" />
			<label>Nu-step</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Nu-step" />
             <label>Nu-step</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="positioning")||($arr[$i]=="positioning\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "positioning" checked="true" />
			<label>positioning</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "positioning" />
             <label>positioning</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="edema reduction/control & management")||($arr[$i]=="edema reduction/control & management\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "edema reduction/control & management" checked="true" />
			<label>edema reduction/control & management</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "edema reduction/control & management" />
             <label>edema reduction/control & management</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Neuromuscular Development Technique")||($arr[$i]=="Neuromuscular Development Technique\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Neuromuscular Development Technique" checked="true" />
			<label>Neuromuscular Development Technique</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Neuromuscular Development Technique" />
             <label>Neuromuscular Development Technique</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="pendulum exercise")||($arr[$i]=="pendulum exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pendulum exercise" checked="true" />
			<label>pendulum exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pendulum exercise" />
             <label>pendulum exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="isometric- cervical spine")||($arr[$i]=="isometric- cervical spine\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- cervical spine" checked="true" />
			<label>isometric- cervical spine</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- cervical spine" />
             <label>isometric- cervical spine</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="PROM/AROM exercise")||($arr[$i]=="PROM/AROM exercise\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "PROM/AROM exercise" checked="true" />
			<label>PROM/AROM exercise</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "PROM/AROM exercise" />
             <label>PROM/AROM exercise</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="straight leg raises")||($arr[$i]=="straight leg raises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "straight leg raises" checked="true" />
			<label>straight leg raises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "straight leg raises" />
             <label>straight leg raises</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="isometrics- quads")||($arr[$i]=="isometrics- quads\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- quads" checked="true" />
			<label>isometrics- quads</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- quads" />
             <label>isometrics- quads</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="isometrics- hamstrings")||($arr[$i]=="isometrics- hamstrings\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- hamstrings" checked="true" />
			<label>isometrics- hamstrings</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- hamstrings" />
             <label>isometrics- hamstrings</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="ankle pumps")||($arr[$i]=="ankle pumps\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle pumps" checked="true" />
			<label>ankle pumps</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle pumps" />
             <label>ankle pumps</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip abduction")||($arr[$i]=="hip abduction\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip abduction" checked="true" />
			<label>hip abduction</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip abduction" />
             <label>hip abduction</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip flexion")||($arr[$i]=="hip flexion\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip flexion" checked="true" />
			<label>hip flexion</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip flexion" />
             <label>hip flexion</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip extension")||($arr[$i]=="hip extension\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip extension" checked="true" />
			<label>hip extension</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip extension" />
             <label>hip extension</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hip adduction")||($arr[$i]=="hip adduction\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip adduction" checked="true" />
			<label>hip adduction</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip adduction" />
             <label>hip adduction</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="heel slides")||($arr[$i]=="heel slides\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel slides" checked="true" />
			<label>heel slides</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel slides" />
             <label>heel slides</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="bridging")||($arr[$i]=="bridging\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bridging" checked="true" />
			<label>bridging</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bridging" />
             <label>bridging</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="buttock squeezes")||($arr[$i]=="buttock squeezes\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "buttock squeezes" checked="true" />
			<label>buttock squeezes</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "buttock squeezes" />
             <label>buttock squeezes</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="knee flexions")||($arr[$i]=="knee flexions\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee flexions" checked="true" />
			<label>knee flexions</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee flexions" />
             <label>knee flexions</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="knee extensions")||($arr[$i]=="knee extensions\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee extensions" checked="true" />
			<label>knee extensions</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee extensions" />
             <label>knee extensions</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="SAQ")||($arr[$i]=="SAQ\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "SAQ" checked="true" />
			<label>SAQ</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "SAQ" />
             <label>SAQ</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="LAQ")||($arr[$i]=="LAQ\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "LAQ" checked="true" />
			<label>LAQ</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "LAQ" />
             <label>LAQ</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="heel raises")||($arr[$i]=="heel raises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel raises" checked="true" />
			<label>heel raises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel raises" />
             <label>heel raises</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="toe raises")||($arr[$i]=="toe raises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "toe raises" checked="true" />
			<label>toe raises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "toe raises" />
             <label>toe raises</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="pelvic tilts")||($arr[$i]=="pelvic tilts\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pelvic tilts" checked="true" />
			<label>pelvic tilts</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pelvic tilts" />
             <label>pelvic tilts</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="squats")||($arr[$i]=="squats\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "squats" checked="true" />
			<label>squats</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "squats" />
             <label>squats</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="shallow knee bends")||($arr[$i]=="shallow knee bends\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "shallow knee bends" checked="true" />
			<label>shallow knee bends</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "shallow knee bends" />
             <label>shallow knee bends</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="isometric- shoulder")||($arr[$i]=="isometric- shoulder\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- shoulder" checked="true" />
			<label>isometric- shoulder</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- shoulder" />
             <label>isometric- shoulder</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="wall climbing")||($arr[$i]=="wall climbing\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall climbing" checked="true" />
			<label>wall climbing</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall climbing" />
             <label>wall climbing</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="restorator")||($arr[$i]=="restorator\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "restorator" checked="true" />
			<label>restorator</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "restorator" />
             <label>restorator</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="recumbant bicycle")||($arr[$i]=="recumbant bicycle\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "recumbant bicycle" checked="true" />
			<label>recumbant bicycle</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "recumbant bicycle" />
             <label>recumbant bicycle</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="upper body bicycle")||($arr[$i]=="upper body bicycle\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "upper body bicycle" checked="true" />
			<label>upper body bicycle</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "upper body bicycle" />
             <label>upper body bicycle</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="wall push ups")||($arr[$i]=="wall push ups\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall push ups" checked="true" />
			<label>wall push ups</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall push ups" />
             <label>wall push ups</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="ankle/foot exercises")||($arr[$i]=="ankle/foot exercises\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle/foot exercises" checked="true" />
			<label>ankle/foot exercises</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle/foot exercises" />
             <label>ankle/foot exercises</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="wall squats")||($arr[$i]=="wall squats\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall squats" checked="true" />
			<label>wall squats</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall squats" />
             <label>wall squats</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="pulleys")||($arr[$i]=="pulleys\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pulleys" checked="true" />
			<label>pulleys</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pulleys" />
             <label>pulleys</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="scapular stabilizing ex's")||($arr[$i]=="scapular stabilizing ex's\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "scapular stabilizing ex's" checked="true" />
			<label>scapular stabilizing ex's</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "scapular stabilizing ex's" />
             <label>scapular stabilizing ex's</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="work hardening")||($arr[$i]=="work hardening\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "work hardening" checked="true" />
			<label>work hardening</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "work hardening" />
             <label>work hardening</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="job tasks simulation")||($arr[$i]=="job tasks simulation\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "job tasks simulation" checked="true" />
			<label>job tasks simulation</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "job tasks simulation" />
             <label>job tasks simulation</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hand web")||($arr[$i]=="hand web\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hand web" checked="true" />
			<label>hand web</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hand web" />
             <label>hand web</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="putty")||($arr[$i]=="putty\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "putty" checked="true" />
			<label>putty</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "putty" />
             <label>putty</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="dexterity ex")||($arr[$i]=="dexterity ex\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "dexterity ex" checked="true" />
			<label>dexterity ex</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "dexterity ex" />
             <label>dexterity ex</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="fine motor ex")||($arr[$i]=="fine motor ex\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "fine motor ex" checked="true" />
			<label>fine motor ex</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "fine motor ex" />
             <label>fine motor ex</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="gross motor ex")||($arr[$i]=="gross motor ex\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gross motor ex" checked="true" />
			<label>gross motor ex</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gross motor ex" />
             <label>gross motor ex</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="UBE")||($arr[$i]=="UBE\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "UBE" checked="true" />
			<label>UBE</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "UBE" />
             <label>UBE</label></div>
		<?php
		}
	}
	
}
?>


</div>
 
            
          </div>              
            
        
<div id="tab13" class="tab_content">
            <h2>&nbsp;</h2>
            <h2>A:</h2>
      <h3>Existing impairments:</h3>

            <div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Refer to evaluation for assessment of patient")||($arr[$i]=="Refer to evaluation for assessment of patient\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "Refer to evaluation for assessment of patient" checked="true" />
			<label>Refer to evaluation for assessment of patient</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "Refer to evaluation for assessment of patient" />
             <label>Refer to evaluation for assessment of patient</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired balance")||($arr[$i]=="impaired balance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired balance" checked="true" />
			<label>impaired balance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired balance" />
             <label>impaired balance</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired standing balance")||($arr[$i]=="impaired standing balance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired standing balance" checked="true" />
			<label>impaired standing balance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired standing balance" />
             <label>impaired standing balance</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decrease trunk mobility")||($arr[$i]=="decrease trunk mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decrease trunk mobility" checked="true" />
			<label>decrease trunk mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decrease trunk mobility" />
             <label>decrease trunk mobility</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decreased extensibility of hamstrings")||($arr[$i]=="decreased extensibility of hamstrings\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of hamstrings" checked="true" />
			<label>decreased extensibility of hamstrings</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of hamstrings" />
             <label>decreased extensibility of hamstrings</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decreased extensibility of gastroc-soleus complex")||($arr[$i]=="decreased extensibility of gastroc-soleus complex\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of gastroc-soleus complex" checked="true" />
			<label>decreased extensibility of gastroc-soleus complex</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of gastroc-soleus complex" />
             <label>decreased extensibility of gastroc-soleus complex</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decreased pelvic mobility")||($arr[$i]=="decreased pelvic mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased pelvic mobility" checked="true" />
			<label>decreased pelvic mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased pelvic mobility" />
             <label>decreased pelvic mobility</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decreased cervical spine mobility")||($arr[$i]=="decreased cervical spine mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased cervical spine mobility" checked="true" />
			<label>decreased cervical spine mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased cervical spine mobility" />
             <label>decreased cervical spine mobility</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired core strength")||($arr[$i]=="impaired core strength\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired core strength" checked="true" />
			<label>impaired core strength</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired core strength" />
             <label>impaired core strength</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="inability to maintain center of gravity over base of support")||($arr[$i]=="inability to maintain center of gravity over base of support\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to maintain center of gravity over base of support" checked="true" />
			<label>inability to maintain center of gravity over base of support</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to maintain center of gravity over base of support" />
             <label>inability to maintain center of gravity over base of support</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired coordination")||($arr[$i]=="impaired coordination\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired coordination" checked="true" />
			<label>impaired coordination</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired coordination" />
             <label>impaired coordination</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired sensation")||($arr[$i]=="impaired sensation\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired sensation" checked="true" />
			<label>impaired sensation</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired sensation" />
             <label>impaired sensation</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired proprioception")||($arr[$i]=="impaired proprioception\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired proprioception" checked="true" />
			<label>impaired proprioception</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired proprioception" />
             <label>impaired proprioception</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired lower extremity muscle strength")||($arr[$i]=="impaired lower extremity muscle strength\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired lower extremity muscle strength" checked="true" />
			<label>impaired lower extremity muscle strength</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired lower extremity muscle strength" />
             <label>impaired lower extremity muscle strength</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired upper extremity muscle strength")||($arr[$i]=="impaired upper extremity muscle strength\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired upper extremity muscle strength" checked="true" />
			<label>impaired upper extremity muscle strength</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired upper extremity muscle strength" />
             <label>impaired upper extremity muscle strength</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor safety awareness")||($arr[$i]=="poor safety awareness\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor safety awareness" checked="true" />
			<label>poor safety awareness</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor safety awareness" />
             <label>poor safety awareness</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired postural awareness")||($arr[$i]=="impaired postural awareness\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired postural awareness" checked="true" />
			<label>impaired postural awareness</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired postural awareness" />
             <label>impaired postural awareness</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired hip/knee extensors")||($arr[$i]=="impaired hip/knee extensors\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired hip/knee extensors" checked="true" />
			<label>impaired hip/knee extensors</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired hip/knee extensors" />
             <label>impaired hip/knee extensors</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="episode of vertigo persists")||($arr[$i]=="episode of vertigo persists\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episode of vertigo persists" checked="true" />
			<label>episode of vertigo persists</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episode of vertigo persists" />
             <label>episode of vertigo persists</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="episodes of orthostatic hypotension persists")||($arr[$i]=="episodes of orthostatic hypotension persists\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episodes of orthostatic hypotension persists" checked="true" />
			<label>episodes of orthostatic hypotension persists</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episodes of orthostatic hypotension persists" />
             <label>episodes of orthostatic hypotension persists</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="fluctuating blood pressure")||($arr[$i]=="fluctuating blood pressure\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "fluctuating blood pressure" checked="true" />
			<label>fluctuating blood pressure</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "fluctuating blood pressure" />
             <label>fluctuating blood pressure</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unstable vital signs")||($arr[$i]=="unstable vital signs\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable vital signs" checked="true" />
			<label>unstable vital signs</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable vital signs" />
             <label>unstable vital signs</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unstable oxygen saturation")||($arr[$i]=="unstable oxygen saturation\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable oxygen saturation" checked="true" />
			<label>unstable oxygen saturation</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable oxygen saturation" />
             <label>unstable oxygen saturation</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor task carry-over")||($arr[$i]=="poor task carry-over\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor task carry-over" checked="true" />
			<label>poor task carry-over</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor task carry-over" />
             <label>poor task carry-over</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="joint instability")||($arr[$i]=="joint instability\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "joint instability" checked="true" />
			<label>joint instability</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "joint instability" />
             <label>joint instability</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="increased postural sway")||($arr[$i]=="increased postural sway\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "increased postural sway" checked="true" />
			<label>increased postural sway</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "increased postural sway" />
             <label>increased postural sway</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor trunk control")||($arr[$i]=="poor trunk control\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor trunk control" checked="true" />
			<label>poor trunk control</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor trunk control" />
             <label>poor trunk control</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired range of motion of lower extremity")||($arr[$i]=="impaired range of motion of lower extremity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of lower extremity" checked="true" />
			<label>impaired range of motion of lower extremity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of lower extremity" />
             <label>impaired range of motion of lower extremity</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired range of motion of upper extremity")||($arr[$i]=="impaired range of motion of upper extremity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of upper extremity" checked="true" />
			<label>impaired range of motion of upper extremity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of upper extremity" />
             <label>impaired range of motion of upper extremity</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="flaccidity")||($arr[$i]=="flaccidity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "flaccidity" checked="true" />
			<label>flaccidity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "flaccidity" />
             <label>flaccidity</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="hyper tonicity")||($arr[$i]=="hyper tonicity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "hyper tonicity" checked="true" />
			<label>hyper tonicity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "hyper tonicity" />
             <label>hyper tonicity</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="ataxic gait")||($arr[$i]=="ataxic gait\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "ataxic gait" checked="true" />
			<label>ataxic gait</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "ataxic gait" />
             <label>ataxic gait</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="debilitating pain")||($arr[$i]=="debilitating pain\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "debilitating pain" checked="true" />
			<label>debilitating pain</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "debilitating pain" />
             <label>debilitating pain</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="weak core strength")||($arr[$i]=="weak core strength\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weak core strength" checked="true" />
			<label>weak core strength</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weak core strength" />
             <label>weak core strength</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor righting reaction")||($arr[$i]=="poor righting reaction\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor righting reaction" checked="true" />
			<label>poor righting reaction</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor righting reaction" />
             <label>poor righting reaction</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="visual impairment")||($arr[$i]=="visual impairment\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "visual impairment" checked="true" />
			<label>visual impairment</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "visual impairment" />
             <label>visual impairment</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="edema of extremity")||($arr[$i]=="edema of extremity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "edema of extremity" checked="true" />
			<label>edema of extremity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "edema of extremity" />
             <label>edema of extremity</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="gait deviations persist")||($arr[$i]=="gait deviations persist\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "gait deviations persist" checked="true" />
			<label>gait deviations persist</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "gait deviations persist" />
             <label>gait deviations persist</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired transfers")||($arr[$i]=="impaired transfers\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired transfers" checked="true" />
			<label>impaired transfers</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired transfers" />
             <label>impaired transfers</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired bed mobility")||($arr[$i]=="impaired bed mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired bed mobility" checked="true" />
			<label>impaired bed mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired bed mobility" />
             <label>impaired bed mobility</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired gait")||($arr[$i]=="impaired gait\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired gait" checked="true" />
			<label>impaired gait</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired gait" />
             <label>impaired gait</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="compromised endurance")||($arr[$i]=="compromised endurance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "compromised endurance" checked="true" />
			<label>compromised endurance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "compromised endurance" />
             <label>compromised endurance</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="limiting pain")||($arr[$i]=="limiting pain\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limiting pain" checked="true" />
			<label>limiting pain</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limiting pain" />
             <label>limiting pain</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="limited standing endurance")||($arr[$i]=="limited standing endurance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limited standing endurance" checked="true" />
			<label>limited standing endurance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limited standing endurance" />
             <label>limited standing endurance</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="shortness of breath with exertion")||($arr[$i]=="shortness of breath with exertion\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "shortness of breath with exertion" checked="true" />
			<label>shortness of breath with exertion</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "shortness of breath with exertion" />
             <label>shortness of breath with exertion</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor body mechanics")||($arr[$i]=="poor body mechanics\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor body mechanics" checked="true" />
			<label>poor body mechanics</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor body mechanics" />
             <label>poor body mechanics</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="muscle spasms (decrease extensibility of muscle fibers)")||($arr[$i]=="muscle spasms (decrease extensibility of muscle fibers)\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "muscle spasms (decrease extensibility of muscle fibers)" checked="true" />
			<label>muscle spasms (decrease extensibility of muscle fibers)</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "muscle spasms (decrease extensibility of muscle fibers)" />
             <label>muscle spasms (decrease extensibility of muscle fibers)</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="decreased functional reach")||($arr[$i]=="decreased functional reach\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased functional reach" checked="true" />
			<label>decreased functional reach</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased functional reach" />
             <label>decreased functional reach</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="inability to bend/lift and carry")||($arr[$i]=="inability to bend/lift and carry\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to bend/lift and carry" checked="true" />
			<label>inability to bend/lift and carry</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to bend/lift and carry" />
             <label>inability to bend/lift and carry</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired unilateral standing balance")||($arr[$i]=="impaired unilateral standing balance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired unilateral standing balance" checked="true" />
			<label>impaired unilateral standing balance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired unilateral standing balance" />
             <label>impaired unilateral standing balance</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="still require assistance to perform shower/bath transfers")||($arr[$i]=="still require assistance to perform shower/bath transfers\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "still require assistance to perform shower/bath transfers" checked="true" />
			<label>still require assistance to perform shower/bath transfers</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "still require assistance to perform shower/bath transfers" />
             <label>still require assistance to perform shower/bath transfers</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="inability to ambulate on unlevel surfaces")||($arr[$i]=="inability to ambulate on unlevel surfaces\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to ambulate on unlevel surfaces" checked="true" />
			<label>inability to ambulate on unlevel surfaces</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to ambulate on unlevel surfaces" />
             <label>inability to ambulate on unlevel surfaces</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="high risk for falls")||($arr[$i]=="high risk for falls\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "high risk for falls" checked="true" />
			<label>high risk for falls</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "high risk for falls" />
             <label>high risk for falls</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="assistance still required for light household tasks")||($arr[$i]=="assistance still required for light household tasks\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for light household tasks" checked="true" />
			<label>assistance still required for light household tasks</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for light household tasks" />
             <label>assistance still required for light household tasks</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="assistance still required for dressing/grooming")||($arr[$i]=="assistance still required for dressing/grooming\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for dressing/grooming" checked="true" />
			<label>assistance still required for dressing/grooming</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for dressing/grooming" />
             <label>assistance still required for dressing/grooming</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="assistance still required for toileting")||($arr[$i]=="assistance still required for toileting\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for toileting" checked="true" />
			<label>assistance still required for toileting</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for toileting" />
             <label>assistance still required for toileting</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="assistance required for laundering/shopping")||($arr[$i]=="assistance required for laundering/shopping\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance required for laundering/shopping" checked="true" />
			<label>assistance required for laundering/shopping</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance required for laundering/shopping" />
             <label>assistance required for laundering/shopping</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unable to ambulate outdoors")||($arr[$i]=="unable to ambulate outdoors\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate outdoors" checked="true" />
			<label>unable to ambulate outdoors</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate outdoors" />
             <label>unable to ambulate outdoors</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unable to ambulate without assistance/supervision")||($arr[$i]=="unable to ambulate without assistance/supervision\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate without assistance/supervision" checked="true" />
			<label>unable to ambulate without assistance/supervision</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate without assistance/supervision" />
             <label>unable to ambulate without assistance/supervision</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unsteady gait")||($arr[$i]=="unsteady gait\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unsteady gait" checked="true" />
			<label>unsteady gait</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unsteady gait" />
             <label>unsteady gait</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="unable to ambulate on uneven terrain")||($arr[$i]=="unable to ambulate on uneven terrain\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate on uneven terrain" checked="true" />
			<label>unable to ambulate on uneven terrain</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate on uneven terrain" />
             <label>unable to ambulate on uneven terrain</label></div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="poor dexterity")||($arr[$i]=="poor dexterity\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor dexterity" checked="true" />
			<label>poor dexterity</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor dexterity" />
             <label>poor dexterity</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="weakness of hand/arm/shoulder")||($arr[$i]=="weakness of hand/arm/shoulder\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weakness of hand/arm/shoulder" checked="true" />
			<label>weakness of hand/arm/shoulder</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weakness of hand/arm/shoulder" />
             <label>weakness of hand/arm/shoulder</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="impaired grip strength")||($arr[$i]=="impaired grip strength\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired grip strength" checked="true" />
			<label>impaired grip strength</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired grip strength" />
             <label>impaired grip strength</label></div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="none")||($arr[$i]=="none\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "none" checked="true" />
			<label>none</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "none" />
             <label>none</label></div>
		<?php
		}
	}
}
?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class = "holder1"><textarea style="color: red; background-color: lightyellow"   name="soap_A_EI_Box" cols="100" rows="4" ><?php
if(! feof($file))
{
	$buff = fgets($file);
	//get the content from text file untill the "..." shows up
	while(! feof($file))
	{
		if($buff=="...\n")
		{
			break;
		}
		$nextline=fgets($file);
		if($nextline=="...\n")
		{
			echo $buff;
			break;
		}
		$buff.=$nextline;
	}
}
?>
</textarea> </div></div>
  




            
      </div>                          
            
           


            
          
<div id="tab14" class="tab_content">
          
            <h2>A:</h2>

            <h3>Gait Deviations:</h3>
            
            
             <p>
			 <?php
			 if(!feof($file))
			 {
			 	$buff = fgets($file);
				if(($buff=="Refer to Evaluation.")||($buff=="Refer to Evaluation.\n"))
				{
				?>
				<input type="checkbox" name="soap_O_Gait" value= "Refer to Evaluation." checked="checked" />
				<?php
				}
				else
				{
				?>
				<input type="checkbox" name="soap_O_Gait" value= "Refer to Evaluation." />
				<?php
				}
			 }
			 ?>
    
    <label>Refer to Evaluation</label>
  </p>
  <p>
    
    <?php
			 if(!feof($file))
			 {
			 	$buff = fgets($file);
				if(($buff=="NA")||($buff=="NA\n"))
				{
				?>
				<input type="checkbox" name="soap_O_Gait1" value= "NA" checked="true" />
				<?php
				}
				else
				{
				?>
				<input type="checkbox" name="soap_O_Gait1" value= "NA" />
				<?php
				}
			 }
			 ?>
    <label>NA</label>
  </p>
  
  <p>
    
    <?php
			 if(!feof($file))
			 {
			 	$buff = fgets($file);
				if(($buff=="none")||($buff=="none\n"))
				{
				?>
				<input type="checkbox" name="soap_O_Gait2" value= "none" checked="true" />
				<?php
				}
				else
				{
				?>
				<input type="checkbox" name="soap_O_Gait2" value= "none" />
				<?php
				}
			 }
			 ?>
    <label>none</label>
  </p>
<textarea style="color: red; background-color: lightyellow" name="soap_O_Gait_Box" cols="100" rows="4"  />
<?php
if(! feof($file))
{
	$buff = fgets($file);
	//get the content from text file untill the "..." shows up
	while(! feof($file))
	{
		if($buff=="...\n")
		{
			break;
		}
		$nextline=fgets($file);
		if($nextline=="...\n")
		{
			echo $buff;
			break;
		}
		$buff.=$nextline;
	}
}
?>
</textarea>
            
            </div>     
            
            
             
             
             
             <div id="tab15" class="tab_content">
             <h2>A:</h2>
            <h3>Rehab Potential:</h3>
            
            <div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt tolerated treatment well- with no exacerbation of symptoms")||($arr[$i]=="Pt tolerated treatment well- with no exacerbation of symptoms\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt tolerated treatment well- with no exacerbation of symptoms" checked="true" />
			<label>Pt tolerated treatment well- with no exacerbation of symptoms</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt tolerated treatment well- with no exacerbation of symptoms" />
			<label>Pt tolerated treatment well- with no exacerbation of symptoms</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. able to tolerate treatment with frequent rest periods")||($arr[$i]=="Pt. able to tolerate treatment with frequent rest periods\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. able to tolerate treatment with frequent rest periods" checked="true" />
			<label>Pt. able to tolerate treatment with frequent rest periods</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. able to tolerate treatment with frequent rest periods" />
			<label>Pt. able to tolerate treatment with frequent rest periods</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt's functional status has improved secondary to skilled Physical Therapy")||($arr[$i]=="Pt's functional status has improved secondary to skilled Physical Therapy\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt's functional status has improved secondary to skilled Physical Therapy" checked="true" />
			<label>Pt's functional status has improved secondary to skilled Physical Therapy</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt's functional status has improved secondary to skilled Physical Therapy" />
			<label>Pt's functional status has improved secondary to skilled Physical Therapy</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. is compliant with POC")||($arr[$i]=="Pt. is compliant with POC\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is compliant with POC" checked="true" />
			<label>Pt. is compliant with POC</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is compliant with POC" />
			<label>Pt. is compliant with POC</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. is making consistent progress towards STG's")||($arr[$i]=="Pt. is making consistent progress towards STG's\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards STG's" checked="true" />
			<label>Pt. is making consistent progress towards STG's</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards STG's" />
			<label>Pt. is making consistent progress towards STG's</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. is making consistent progress towards LTG's")||($arr[$i]=="Pt. is making consistent progress towards LTG's\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards LTG's" checked="true" />
			<label>Pt. is making consistent progress towards LTG's</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards LTG's" />
			<label>Pt. is making consistent progress towards LTG's</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Improvement to realize PLOF is anticipated")||($arr[$i]=="Improvement to realize PLOF is anticipated\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Improvement to realize PLOF is anticipated" checked="true" />
			<label>Improvement to realize PLOF is anticipated</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Improvement to realize PLOF is anticipated" />
			<label>Improvement to realize PLOF is anticipated</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Skilled Physical Therapy still warranted to promote safety awareness and minimize falls")||($arr[$i]=="Skilled Physical Therapy still warranted to promote safety awareness and minimize falls\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical Therapy still warranted to promote safety awareness and minimize falls" checked="true" />
			<label>Skilled Physical Therapy still warranted to promote safety awareness and minimize falls</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical Therapy still warranted to promote safety awareness and minimize falls" />
			<label>Skilled Physical Therapy still warranted to promote safety awareness and minimize falls</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Skilled Physical therapy warranted to improve balance and enhance rehab potential")||($arr[$i]=="Skilled Physical therapy warranted to improve balance and enhance rehab potential\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical therapy warranted to improve balance and enhance rehab potential" checked="true" />
			<label>Skilled Physical therapy warranted to improve balance and enhance rehab potential</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical therapy warranted to improve balance and enhance rehab potential" />
			<label>Skilled Physical therapy warranted to improve balance and enhance rehab potential</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Maximum potential is yet to be obtained")||($arr[$i]=="Maximum potential is yet to be obtained\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Maximum potential is yet to be obtained" checked="true" />
			<label>Maximum potential is yet to be obtained</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Maximum potential is yet to be obtained" />
			<label>Maximum potential is yet to be obtained</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Functional mobility has improved, evidenced by increased independence with self care")||($arr[$i]=="Functional mobility has improved, evidenced by increased independence with self care\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Functional mobility has improved, evidenced by increased independence with self care" checked="true" />
			<label>Functional mobility has improved, evidenced by increased independence with self care</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Functional mobility has improved, evidenced by increased independence with self care" />
			<label>Functional mobility has improved, evidenced by increased independence with self care</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Gains noted in MS and balance, evidenced by improved transfers and ambulation")||($arr[$i]=="Gains noted in MS and balance, evidenced by improved transfers and ambulation\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in MS and balance, evidenced by improved transfers and ambulation" checked="true" />
			<label>Gains noted in MS and balance, evidenced by improved transfers and ambulation</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in MS and balance, evidenced by improved transfers and ambulation" />
			<label>Gains noted in MS and balance, evidenced by improved transfers and ambulation</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S")||($arr[$i]=="Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S" checked="true" />
			<label>Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S" />
			<label>Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S</label> </div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility")||($arr[$i]=="Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility" checked="true" />
			<label>Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility" />
			<label>Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility</label> </div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Steady gains noted in ROM and MS evidenced by improved self care abilities")||($arr[$i]=="Steady gains noted in ROM and MS evidenced by improved self care abilities\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Steady gains noted in ROM and MS evidenced by improved self care abilities" checked="true" />
			<label>Steady gains noted in ROM and MS evidenced by improved self care abilities</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Steady gains noted in ROM and MS evidenced by improved self care abilities" />
			<label>Steady gains noted in ROM and MS evidenced by improved self care abilities</label> </div>
		<?php
		}
	}
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Gains noted in balance evidenced by improved transfers")||($arr[$i]=="Gains noted in balance evidenced by improved transfers\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in balance evidenced by improved transfers" checked="true" />
			<label>Gains noted in balance evidenced by improved transfers</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in balance evidenced by improved transfers" />
			<label>Gains noted in balance evidenced by improved transfers</label> </div>
		<?php
		}
	}

}
?>


<div class = "holder"></div> 
  <div class = "holder"></div>
  <div class = "holder"></div>
   <div class = "holder"></div>
  <div class = "holder"></div>
 <div class = "holder"></div>
  <div class = "holder"></div>
     
     

  
    
 
  
   <p>&nbsp;</p>
   <div class = "holder1"> <textarea style="color: red; background-color: lightyellow" name="soap_A_RP_Box" cols="100" rows="4"  ><?php
if(! feof($file))
{
	$buff = fgets($file);
	//get the content from text file untill the "..." shows up
	while(! feof($file))
	{
		if($buff=="...\n")
		{
			break;
		}
		$nextline=fgets($file);
		if($nextline=="...\n")
		{
			echo $buff;
			break;
		}
		$buff.=$nextline;
	}
}
?></textarea></div></div>   
            
            </div>  
            
             
             
                        
    
    <div id="tab16" class="tab_content">
            <h2>P:</h2>
            
      <div id = "container">
<?php
if(! feof($file))
{
	$buff = fgets($file);
	$arr=explode("|",$buff);
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical therapy to continue as planned")||($arr[$i]=="Physical therapy to continue as planned\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical therapy to continue as planned" checked="checked" />
			<label>Physical therapy to continue as planned</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical therapy to continue as planned" />
			<label>Physical therapy to continue as planned</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to continue to focus on improving functional mobility")||($arr[$i]=="Physical Therapy to continue to focus on improving functional mobility\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving functional mobility" checked="checked" />
			<label>Physical Therapy to continue to focus on improving functional mobility</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving functional mobility" />
			<label>Physical Therapy to continue to focus on improving functional mobility</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to continue to focus on improving balance, so as to increase independence")||($arr[$i]=="Physical Therapy to continue to focus on improving balance, so as to increase independence\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving balance, so as to increase independence" checked="checked" />
			<label>Physical Therapy to continue to focus on improving balance, so as to increase independence</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving balance, so as to increase independence" />
			<label>Physical Therapy to continue to focus on improving balance, so as to increase independence</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to continue to focus on improving core strength , so as to resume PLOF")||($arr[$i]=="Physical Therapy to continue to focus on improving core strength , so as to resume PLOF\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving core strength , so as to resume PLOF" checked="checked" />
			<label>Physical Therapy to continue to focus on improving core strength , so as to resume PLOF</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving core strength , so as to resume PLOF" />
			<label>Physical Therapy to continue to focus on improving core strength , so as to resume PLOF</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls")||($arr[$i]=="Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls" checked="checked" />
			<label>Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls" />
			<label>Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to continue to focus on improving community ambulation, so as to resume independence")||($arr[$i]=="Physical Therapy to continue to focus on improving community ambulation, so as to resume independence\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving community ambulation, so as to resume independence" checked="checked" />
			<label>Physical Therapy to continue to focus on improving community ambulation, so as to resume independence</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving community ambulation, so as to resume independence" />
			<label>Physical Therapy to continue to focus on improving community ambulation, so as to resume independence</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care")||($arr[$i]=="Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care" checked="checked" />
			<label>Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care" />
			<label>Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Continue with POC")||($arr[$i]=="Continue with POC\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Continue with POC" checked="checked" />
			<label>Continue with POC</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Continue with POC" />
			<label>Continue with POC</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Discuss progress/concerns with MD")||($arr[$i]=="Discuss progress/concerns with MD\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Discuss progress/concerns with MD" checked="checked" />
			<label>Discuss progress/concerns with MD</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Discuss progress/concerns with MD" />
			<label>Discuss progress/concerns with MD</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to focus on safety awareness")||($arr[$i]=="Physical Therapy to focus on safety awareness\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on safety awareness" checked="checked" />
			<label>Physical Therapy to focus on safety awareness</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on safety awareness" />
			<label>Physical Therapy to focus on safety awareness</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall")||($arr[$i]=="Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall" checked="checked" />
			<label>Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall" />
			<label>Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Focus will be on work hardening to enable pt. to return to work w/o symptoms")||($arr[$i]=="Focus will be on work hardening to enable pt. to return to work w/o symptoms\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus will be on work hardening to enable pt. to return to work w/o symptoms" checked="checked" />
			<label>Focus will be on work hardening to enable pt. to return to work w/o symptoms</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus will be on work hardening to enable pt. to return to work w/o symptoms" />
			<label>Focus will be on work hardening to enable pt. to return to work w/o symptoms</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms")||($arr[$i]=="Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms" checked="checked" />
			<label>Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms" />
			<label>Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms")||($arr[$i]=="Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms" checked="checked" />
			<label>Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms" />
			<label>Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. discharged to HEP")||($arr[$i]=="Pt. discharged to HEP\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. discharged to HEP" checked="checked" />
			<label>Pt. discharged to HEP</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. discharged to HEP" />
			<label>Pt. discharged to HEP</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt. has reached maximal potential, PT discharged")||($arr[$i]=="Pt. has reached maximal potential, PT discharged\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. has reached maximal potential, PT discharged" checked="checked" />
			<label>Pt. has reached maximal potential, PT discharged</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. has reached maximal potential, PT discharged" />
			<label>Pt. has reached maximal potential, PT discharged</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Pt has achieved all established goals")||($arr[$i]=="Pt has achieved all established goals\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt has achieved all established goals" checked="checked" />
			<label>Pt has achieved all established goals</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt has achieved all established goals" />
			<label>Pt has achieved all established goals</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="PT discharged")||($arr[$i]=="PT discharged\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged" checked="checked" />
			<label>PT discharged</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged" />
			<label>PT discharged</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="PT discharged secondary to non compliance with attendance")||($arr[$i]=="PT discharged secondary to non compliance with attendance\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged secondary to non compliance with attendance" checked="checked" />
			<label>PT discharged secondary to non compliance with attendance</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged secondary to non compliance with attendance" />
			<label>PT discharged secondary to non compliance with attendance</label> </div>
		<?php
		}
	}
	
	$i=0;
	while($i<count($arr))
	{
		if(($arr[$i]=="Plan of care established by PT")||($arr[$i]=="Plan of care established by PT\n"))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Plan of care established by PT" checked="checked" />
			<label>Plan of care established by PT</label> </div>
		<?php
			break;
		}
		$i++;
		if($i==count($arr))
		{
		?>
			<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Plan of care established by PT" />
			<label>Plan of care established by PT</label> </div>
		<?php
		}
	}
	
}
?>

<div class = "holder1"> 
  <textarea style="color: red; background-color: lightyellow" name="soap_A_P_Box" cols="100" rows="4"  ><?php
if(! feof($file))
{
	$buff = fgets($file);
	//get the content from text file untill the "..." shows up
	while(! feof($file))
	{
		if($buff=="...\n")
		{
			break;
		}
		$nextline=fgets($file);
		if($nextline=="...\n")
		{
			echo $buff;
			break;
		}
		$buff.=$nextline;
	}
}
?></textarea></div></div>

            
      </div>
            
         
   <div id="tab17" class="tab_content">
            <h2>Time Sheet:</h2>
            
            <p>[Therapeutic ex] &nbsp; &nbsp;&nbsp; [Neuromuscular] &nbsp;&nbsp;&nbsp; [Manual] &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;   [Gait training] &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;[Treatment time]  &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [Total minutes]</p>
 <p>
&nbsp;&nbsp;&nbsp;&nbsp;  
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="TP_ex" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="TP_ex" value= "" size="3"/>
<?php
}
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="NM" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="NM" value= "" size="3"/>
<?php
}
?>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="Man" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="Man" value= "" size="3"/>
<?php
}
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="GT" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="GT" value= "" size="3"/>
<?php
}
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="TT" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="TT" value= "" size="3"/>
<?php
}
?>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
if(!feof($file))
{
	$buff=fgets($file);
?>
<input type="text" name="TM" value= "<?php if($buff!="\n"){$buff=substr($buff,0,-1);echo $buff;}?>" size="3"/>
<?php
}
else
{
?>
<input type="text" name="TM" value= "" size="3"/>
<?php
}
?>
 </p>
            
            
             
                
 <input  type="submit" name="submit"  id="rhButton" value="save" />
            &nbsp; &nbsp;&nbsp;
			<?php
				$filenames="";
				$dir = "patients/";
				// Open a known directory, and proceed to read its contents
				if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
				while (($file = readdir($dh)) !== false) {
					if($file!='.'&& $file!='..')
					$filenames.="|"."$file" ;
				} closedir($dh);
				}
				}
				
				$filenames=substr($filenames, -(strlen($filenames)-1));
			
			?>
			chose the time:<select name="folderName" style= "width:80" onchange="changepatientName(this.value)">
				<option value="0">--choose the patient--</option>
				<?php
				$arr=explode("|",$filenames);
				$i=0;
				while($i<count($arr))
				{
					?>
					<option value=<?php echo$arr[$i]; ?>>
					<?php echo $arr[$i]; ?>
					</option>
					<?php
					$i++;
				}
				?>
			</select>
			<select disabled="disabled" name="patientName" style= "width:190">
				  <option value="0">--please choose the date--</option>
			</select>
			&nbsp; &nbsp;&nbsp;
			<input type="button" value="load" onclick="onclickload(patientName.value)" />
            </div>
            
            
</div>
</div>
<div style="clear: both; display: block; padding: 10px 0; text-align:center;"></div>
<div id="calendarDiv"></div>
</form>
<?php
}
else
{
?>
<form name="drop_list" action="process_form.php" method="post" >

<div class="container">
<h3>Righteous Rehab Inc. dba TOP Physical Therapy</h3>
    <ul class="tabs">
        <li><a href="#tab1">pt. info</a></li>
        <li><a href="#tab2">S:</a></li>
        
       
       
        
        <li><a href="#tab3">O: ADL's/educ</a></li>
        <li><a href="#tab4">O: Balance training</a></li>
        <li><a href="#tab5">O: Core ex/posture</a></li>
        <li><a href="#tab6">O: Endurance training</a></li>
         <li><a href="#tab7">O: Gait training</a></li>
         <li><a href="#tab8">O: Manual</a></li>
         <li><a href="#tab9">O: Modalities</a></li>
         <li><a href="#tab10">O: Mobility training</a></li>
         <li><a href="#tab11">O: Therapeutic stretch</a></li>   
        <li><a href="#tab12">O:  Ther ex</a></li>
        <li><a href="#tab13">A: Existing impairments</a></li>
        
        <li><a href="#tab14">A: Gait deviations</a></li>
          
          
          <li><a href="#tab15">A: Rehab Potential:</a></li>
         
        
        
        <li><a href="#tab16">P:</a></li>
        <li><a href="#tab17">billing/save:</a></li>
		<!--<li><a href="#tab18">view/load:</a></li>-->
    </ul>
    <div class="tab_container">
    
    <div id="tab1" class="tab_content">
            <h2>Patient Info:</h2>
            <p>
					<input type="checkbox" name="checkmark1" value= "Daily Note" />
                <label>Daily Note</label>
					<input type="checkbox" name="checkmark2" value= "Progress Note" />
                <label>Progress Note</label>
                <input type="checkbox" name="checkmark3" value= "Discharge Note" />
                <label>Discharge Note</label>
      <p>                                          
      <p>Name:
                      <input name="soap_name" type="text" id="sub_text" value="" size="50" />
                
      <p>Date: <input type="text" class="calendarSelectDate" name="soap_date" />                     
      <p>Treatment#: <input type="text" name="soap_trnum" value="" />          
                      
      <p>Treating therapist/license#:
                      <input type="checkbox" name="soap_license[]" value= "Maxine Hurley PT 21823" />
                <label>Maxine Hurley PT 21823</label> 
                                      <input type="checkbox" name="soap_license[]" value= "Zebulon Gardner PTA 12528" />
                <label>Zebulon Gardner PTA 12528</label> 
                 <input type="checkbox" name="soap_license[]" value= "Steven Safdia PTA 14630 " />
                <label>Steven Safdia PTA 14630 </label> 
                      
            
      </div>
            
            <div id="tab2" class="tab_content">
            <h2>S:</h2>
            
             <p> <stong>S:</stong>
               <textarea style="color: red; background-color: lightyellow" name="soap_s" cols="100" rows="4"  ></textarea>
             </p>
               <p> <stong></stong>              
               <p></div>
               
               
                <div id="tab3" class="tab_content">
 <h2>O:</h2>
            
             <p>
              <input type="checkbox" name="soap_O_Eval" value= "Patient evaluated today, refer to evaluation for objective findings." />
              <label>Patient evaluated today, refer to evaluation for objective findings.</label>
              </p>
             <p>&nbsp;</p>
            
            <h3>ADL's/educ:</h3>
            
            <p>
   
            
            <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "buttoning/fastening/zippering" />
<label>buttoning/fastening/zippering</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body dressing" />
<label>upper/lower body dressing</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "donning/doffing socks/shoes" />
<label>donning/doffing socks/shoes</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "bend-lift & carry exercise" />
<label>bend-lift & carry exercise</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "toileting safety" />
<label>toileting safety</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "simulated laundry & grocery" />
<label>simulated laundry & grocery</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_SC[]" value= "upper/lower body grooming" />
<label>upper/lower body grooming</label> </div>
<div class = "holder"></div>
<div class = "holder"></div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class = "holder"><h3> *Patient educated on:</h3> <textarea style="color: red; background-color: lightyellow" name="soap_PT_edu" cols="100" rows="4"  ></textarea> </div></div>            
            
            </div> 
            

            
      <div id="tab4" class="tab_content">
    <h2>&nbsp;</h2>
    <h2>O:</h2>
            <h3>Balance training:</h3>
            
        <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "recovery during mobility" />
<label>Balance recovery during mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "bend-lift & carry exercise" />
<label>bend-lift & carry exercise</label><input name="soap_O_BT_box" type="text" id="sub_text" value="" size="8" />     <label>lbs</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Wii (for balance, endurance & strength)" />
<label>Wii (for balance, endurance & strength)</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "standing static/dynamic exercise" />
<label>standing static/dynamic exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "equilibrium challenging  training" />
<label>equilibrium challenging  training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "weight shifting ex" />
<label>weight shifting ex</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "sitting static/dynamic exercise" />
<label>sitting static/dynamic exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "ankle/hip strategy" />
<label>ankle/hip strategy</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular training" />
<label>vestibular training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vertigo ex" />
<label>vertigo ex</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "obstacle negotiation" />
<label>obstacle negotiation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "fall recovery training" />
<label>fall recovery training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement across midline" />
<label>movement across midline</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "single leg stance" />
<label>single leg stance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "Bobath" />
<label>Bobath</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "wobble board" />
<label>wobble board</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "balance beam" />
<label>balance beam</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular rocker board" />
<label>vestibular rocker board</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "vestibular balance disc/wedges" />
<label>vestibular balance disc/wedges</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_BT[]" value= "movement of COG over BOS training" />
<label>movement of COG over BOS training</label> </div></div> 
    
</div>
            
       
       
                  
 <div id="tab5" class="tab_content">
 <h2>O:</h2>
            <h3>Core strengthening/posture:</h3>
            
      <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar stabilization" />
<label>lumbar stabilization</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "lumbar mobility" />
<label>lumbar mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "postural awareness" />
<label>postural awareness</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "strengthening exercise" />
<!--
<label>strengthening exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "core strengthening" />
-->
<label>core strengthening</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "body mechanics" />
<label>body mechanics</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_SP[]" value= "back protection technique" />
<label>back protection technique</label> </div></div> 

</div>
       
            
            
            
            <div id="tab6" class="tab_content">
        <h2>O:</h2>
            <h3>Endurance training:</h3>
<div id = "container">
              <!--  <div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "endurance training" />
<label>endurance training</label> </div> -->

                   <div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "breathing exercise" />
<label>breathing exercise</label> </div>

                   <div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "diaphragmatic breathing exercise" />
<label>diaphragmatic breathing exercise</label> </div>

                   <div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "pursed lip breathing exercise" />
<label>pursed lip breathing exercise</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "bike " />
<label>bike</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Nu step " />
<label>Nu step</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "treadmill" />
<label>treadmill</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "incentive spirometer" />
<label>incentive spirometer</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "UBE" />
<label>UBE</label> </div

><div class = "holder"><input type="checkbox" name="soap_O_ET[]" value= "Wii fitness training" />
<label>Wii fitness training</label> </div></div> 
        
      </div>
            
            
            
                
 <div id="tab7" class="tab_content">
 <h2>O:</h2>
            <h3>Gait training:</h3>
            
      <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "braiding" />
<label>braiding</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tandem walking" />
<label>tandem walking</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "outdoor ambulation" />
<label>outdoor ambulation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "curb training" />
<label>curb training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "stair training" />
<label>stair training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training w/o assistive device" />
<label>gait training w/o assistive device</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "gait training with prosthesis" />
<label>gait training with prosthesis</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "tilt table" />
<label>tilt table</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "standing training" />
<label>standing training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "side stepping" />
<label>side stepping</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "marching" />
<label>marching</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking with resistance" />
<label>walking with resistance</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "walking backwards" />
<label>walking backwards</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_GT[]" value= "treadmill" />
<label>treadmill</label> </div></div> 

            
      </div>
            
    
    
    
    <div id="tab8" class="tab_content">
        <h2>O:</h2>
            <h3>Manual:</h3>
<div id = "container">
               <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "joint mobs of" />
             <label>joint mobs of</label><input name="soap_O_Man_box" type="text" id="sub_text2"  size="15" /></div>
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual lymph drainage" />
             <label>manual lymph drainage</label> </div>
            <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "manual traction to" />
             <label>manual traction to</label><input name="soap_O_Man_box2" type="text" id="sub_text"  size="15" /> </div>  
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "taping" />
             <label>taping</label> </div>
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump wrapping" />
             <label>stump wrapping</label> </div>
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "stump care" />
             <label>stump care</label> </div>  
             
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "chest physical therapy" />
             <label>chest physical therapy</label> </div> 
             
             <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "massage to" />
             <label>massage to</label><input name="soap_O_Man_box3" type="text" id="sub_text"  size="15" /> </div> 
             
        <div class = "holder"><input type="checkbox" name="soap_O_Man[]" value= "myofascial release" />
      <label>myofascial release</label> </div></div>             
            
      </div>
        
    
            
            
<div id="tab9" class="tab_content">
            <h2>O:</h2>
           
            
            <h3>&nbsp;</h3>
            <p>&nbsp;</p>
            <h3>Modalities:</h3>
            
<div id = "container">
               <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ultrasound to" />
                <label>ultrasound to</label><input name="soap_O_M_box" type="text" id="sub_text" value="" size="15" /> </div><label for="soap_O_M_box"></label>
                <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "electrical stimulation to" />
                <label>electrical stimulation to</label><input name="soap_O_M_box2" type="text" id="sub_text" value="" size="15" /> </div>
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "anodyne to" />
                <label>anodyne to</label><input name="soap_O_M_box3" type="text" id="sub_text" value="" size="15" /> </div>
                
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "ETPS to" />
                <label>ETPS to</label><input name="soap_O_M_box4" type="text" id="sub_text" value="" size="15" /> </div>
                
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold laser to" />
                <label>cold laser to</label><input name="soap_O_M_box5" type="text" id="sub_text" value="" size="15" /> </div>
                
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "moist heat to" />
                <label>moist heat to</label><input name="soap_O_M_box6" type="text" id="sub_text" value="" size="15" /> </div>
                
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "cold pack to" />
                <label>cold pack to</label><input name="soap_O_M_box7" type="text" id="sub_text" value="" size="15" /> </div>
                
                 <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "contrast bath" />
                <label>contrast bath</label> </div>
              
               <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "iontophoresis to" />
                <label>iontophoresis to</label><input name="soap_O_M_box8" type="text" id="sub_text" value="" size="15" /> </div>  
               
              
               <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "phonophoresis to" />
                <label>phonophoresis to</label><input name="soap_O_M_box9" type="text" id="sub_text" value="" size="15" /> </div> 
              
               <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "biofeedback" />
                <label>biofeedback</label></div>
               
               <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "paraffin" />
                <label>paraffin</label> </div>
                
        <div class = "holder"><input type="checkbox" name="soap_O_M[]" value= "medi cupping massage" />
      <label>medi cupping massage</label> </div></div>                 
                

   </div>
        
        
        
         <div id="tab10" class="tab_content">
         <h2>O:</h2>
            <h3>Mobility training:</h3>
            
           <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "transfer training" />
<label>transfer training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "car transfer training" />
<label>car transfer training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bed mobility training" />
<label>bed mobility training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sliding board transfer" />
<label>sliding board transfer</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "bathtub/shower transfer training" />
<label>bathtub/shower transfer training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "practice getting up from fall" />
<label>practice getting up from fall</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "wheelchair training" />
<label>wheelchair training</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_MT[]" value= "sit to stand exercises" />
<label>sit to stand exercises</label> </div></div> 
        
</div>
    


 
            
            
            <div id="tab11" class="tab_content">
        <h2>O:</h2>
<h3>Therapeutic stretch: elongation provided to</h3>
<div id = "container">
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hamstrings" />
                <label>hamstrings </label>
                </div>
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "quads" />
                <label>quads</label> </div>
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "piriformis" />
                <label>piriformis </label> </div>
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "Cervical spine/upper traps stretches" />
                <label>Cervical spine/upper traps stretches</label> </div>
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "traction of" />
                <label>traction of</label><input name="soap_O_TS_box" type="text" id="sub_text" value="" size="15" /> </div>
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "l/s paraspinals" />
                <label>l/s paraspinals</label> </div>
               <!-- <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "DKTC" >
                <label>DKTC</label> </div> -->
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "carpal tunnel" />
                <label>carpal tunnel</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "gastro-soleus complex" />
                <label>gastro-soleus complex</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip ERs" />
                <label>hip ERs</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip IRs" />
                <label>hip IRs</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip abductors" />
                <label>hip abductors</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "hip adductors" />
                <label>hip adductors</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "supinators" />
                <label>supinators</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "pronators" />
                <label>pronators</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "upper traps" />
                <label>upper traps</label> </div>
                
                <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder IRs" />
                <label>shoulder IRs</label> </div>
                
        <div class = "holder"><input type="checkbox" name="soap_O_TS[]" value= "shoulder ERs" />
              <label>shoulder ERs</label> </div></div> 
    
</div>
            
            
            
            
  <div id="tab12" class="tab_content">
  <h2>O:</h2>
            <h3>Therapeutic exercise:</h3>
            
            <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "resistive exercise" />
<label>resistive exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "open chain exercise" />
<label>open chain exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "close chain exercise" />
<label>close chain exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Proprioceptive Neuromuscular Facilitation" />
<label>Proprioceptive Neuromuscular Facilitation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "contract/relax technique" />
<label>contract/relax technique</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity eliminated exercise" />
<label>gravity eliminated exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gravity assistive exercise" />
<label>gravity assistive exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isokinetics" />
<label>isokinetics</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "therapeutic exercise w/gym ball" />
<label>therapeutic exercise w/gym ball</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "thera-band exercises" />
<label>thera-band exercises</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "treadmill" />
<label>treadmill</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bike" />
<label>bike</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Nu-step" />
<label>Nu-step</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "positioning" />
<label>positioning</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "edema reduction/control & management" />
<label>edema reduction/control & management</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "Neuromuscular Development Technique" />
<label>Neuromuscular Development Technique</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pendulum exercise" />
<label>pendulum exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- cervical spine  " />
<label>isometric- cervical spine  </label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "PROM/AROM exercise" />
<label>PROM/AROM exercise</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "straight leg raises" />
<label>straight leg raises</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- quads" />
<label>isometrics- quads</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometrics- hamstrings" />
<label>isometrics- hamstrings</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle pumps" />
<label>ankle pumps</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip abduction" />
<label>hip abduction</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip flexion" />
<label>hip flexion</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip extension" />
<label>hip extension</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hip adduction" />
<label>hip adduction</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel slides" />
<label>heel slides</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "bridging" />
<label>bridging</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "buttock squeezes" />
<label>buttock squeezes</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee flexions" />
<label>knee flexions</label></div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "knee extensions" />
<label>knee extensions</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "SAQ" />
<label>SAQ</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "LAQ" />
<label>LAQ</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "heel raises" />
<label>heel raises</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "toe raises" />
<label>toe raises</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pelvic tilts" />
<label>pelvic tilts</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "squats" />
<label>squats</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "shallow knee bends" />
<label>shallow knee bends</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "isometric- shoulder " />
<label>isometric- shoulder </label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall climbing" />
<label>wall climbing</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "restorator" />
<label>restorator</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "recumbant bicycle" />
<label>recumbant bicycle</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "upper body bicycle" />
<label>upper body bicycle</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall push ups" />
<label>wall push ups</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "ankle/foot exercises" />
<label>ankle/foot exercises</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "wall squats" />
<label>wall squats</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "pulleys" />
<label>pulleys</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "scapular stabilizing ex's" />
<label>scapular stabilizing ex's</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "work hardening" />
<label>work hardening</label> </div>
<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "job tasks simulation" />
<label>job tasks simulation</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "hand web" />
<label>hand web</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "putty" />
<label>putty</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "dexterity ex" />
<label>dexterity ex</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "fine motor ex" />
<label>fine motor ex</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "gross motor ex" />
<label>gross motor ex</label> </div>

<div class = "holder"><input type="checkbox" name="soap_O_TE[]" value= "UBE" />
<label>UBE</label> </div>
</div>
 
            
          </div>              
            
        
<div id="tab13" class="tab_content">
            <h2>&nbsp;</h2>
            <h2>A:</h2>
      <h3>Existing impairments:</h3>
            
            <div id = "container">
 <div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "Refer to evaluation for assessment of patient" />
<label>Refer to evaluation for assessment of patient</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired balance" />
<label>impaired balance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired standing balance" />
<label>impaired standing balance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decrease trunk mobility" />
<label>decrease trunk mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of hamstrings" />
<label>decreased extensibility of hamstrings</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased extensibility of gastroc-soleus complex" />
<label>decreased extensibility of gastroc-soleus complex</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased pelvic mobility" />
<label>decreased pelvic mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased cervical spine mobility" />
<label>decreased cervical spine mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired core strength" />
<label>impaired core strength</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to maintain center of gravity over base of support" />
<label>inability to maintain center of gravity over base of support</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired coordination" />
<label>impaired coordination</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired sensation" />
<label>impaired sensation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired proprioception" />
<label>impaired proprioception</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired lower extremity muscle strength" />
<label>impaired lower extremity muscle strength</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired upper extremity muscle strength" />
<label>impaired upper extremity muscle strength</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor safety awareness" />
<label>poor safety awareness</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired postural awareness" />
<label>impaired postural awareness</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired hip/knee extensors" />
<label>impaired hip/knee extensors</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episode of vertigo persists" />
<label>episode of vertigo persists</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "episodes of orthostatic hypotension persists" />
<label>episodes of orthostatic 
hypotension persists</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "fluctuating blood pressure" />
<label>fluctuating blood pressure</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable vital signs" />
<label>unstable vital signs</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unstable oxygen saturation" />
<label>unstable oxygen saturation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor task carry-over" />
<label>poor task carry-over</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "joint instability" />
<label>joint instability</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "increased postural sway" />
<label>increased postural sway</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor trunk control" />
<label>poor trunk control</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of lower extremity" />
<label>impaired range of motion of lower extremity</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired range of motion of upper extremity" />
<label>impaired range of motion of upper extremity</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "flaccidity" />
<label>flaccidity</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "hyper tonicity" />
<label>hyper tonicity</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "ataxic gait" />
<label>ataxic gait</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "debilitating pain" />
<label>debilitating pain</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weak core strength" />
<label>weak core strength</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor righting reaction" />
<label>poor righting reaction</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "visual impairment" />
<label>visual impairment</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "edema of extremity" />
<label>edema of extremity</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "gait deviations persist" />
<label>gait deviations persist</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired transfers" />
<label>impaired transfers</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired bed mobility" />
<label>impaired bed mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired gait" />
<label>impaired gait</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "compromised endurance" />
<label>compromised endurance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limiting pain" />
<label>limiting pain</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "limited standing endurance" />
<label>limited standing endurance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "shortness of breath with exertion"/>
<label>shortness of breath with exertion</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor body mechanics" />
<label>poor body mechanics</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "muscle spasms (decrease extensibility of muscle fibers)" />
<label>muscle spasms (decrease extensibility of muscle fibers)</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "decreased functional reach" />
<label>decreased functional reach</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to bend/lift and carry" />
<label>inability to bend/lift and carry</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired unilateral standing balance" />
<label>impaired unilateral standing balance</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "still require assistance to perform shower/bath transfers" />
<label>still require assistance to perform shower/bath transfers</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "inability to ambulate on unlevel surfaces " />
<label>inability to ambulate on unlevel surfaces </label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "high risk for falls" />
<label>high risk for falls</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for light household tasks" />
<label>assistance still required for light household tasks</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for dressing/grooming" />
<label>assistance still required for dressing/grooming</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance still required for toileting" />
<label>assistance still required for toileting</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "assistance required for laundering/shopping" />
<label>assistance required for laundering/shopping</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate outdoors" />
<label>unable to ambulate outdoors</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate without assistance/supervision" />
<label>unable to ambulate without assistance/supervision</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unsteady gait" />
<label>unsteady gait</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "unable to ambulate on uneven terrain" />
<label>unable to ambulate on uneven terrain</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "poor dexterity" />
<label>poor dexterity</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "weakness of hand/arm/shoulder" />
<label>weakness of hand/arm/shoulder</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "impaired grip strength" />
<label>impaired grip strength</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_EI[]" value= "none" />
<label>none</label> </div>





<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class = "holder1"><textarea style="color: red; background-color: lightyellow"   name="soap_A_EI_Box" cols="100" rows="4" ></textarea> </div></div>
  




            
      </div>                          
            
           


            
          
<div id="tab14" class="tab_content">
          
            <h2>A:</h2>

            <h3>Gait Deviations:</h3>
            
            
             <p>
    <input type="checkbox" name="soap_O_Gait" value= "Refer to Evaluation." />
    <label>Refer to Evaluation</label>
  </p>
  <p>
    
    
    <input type="checkbox" name="soap_O_Gait1" value= "NA" />
    <label>NA</label>
  </p>
  
  <p>
   <input type="checkbox" name="soap_O_Gait2" value= "none" />
    <label>none</label>
    </p>
  <textarea style="color: red; background-color: lightyellow" name="soap_O_Gait_Box" cols="100" rows="4"  /></textarea>
            
            </div>     
            
            
             
             
             
             <div id="tab15" class="tab_content">
             <h2>A:</h2>
            <h3>Rehab Potential:</h3>
            
            <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt tolerated treatment well- with no exacerbation of symptoms" />
<label>Pt tolerated treatment well- with no exacerbation of symptoms</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. able to tolerate treatment with frequent rest periods" />
<label>Pt. able to tolerate treatment with frequent rest periods</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt's functional status has improved secondary to skilled Physical Therapy" />
<label>Pt's functional status has improved secondary to skilled Physical Therapy</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is compliant with POC" />
<label>Pt. is compliant with POC</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards STG's" />
<label>Pt. is making consistent progress towards STG's</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt. is making consistent progress towards LTG's" />
<label>Pt. is making consistent progress towards LTG's</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Improvement to realize PLOF is anticipated" />
<label>Improvement to realize PLOF is anticipated</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical Therapy still warranted to promote safety awareness and minimize falls" />
<label>Skilled Physical Therapy still warranted to promote safety awareness and minimize falls</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Skilled Physical therapy warranted to improve balance and enhance rehab potential" />
<label>Skilled Physical therapy warranted to improve balance and enhance rehab potential</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Maximum potential is yet to be obtained" />
<label>Maximum potential is yet to be obtained</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Functional mobility has improved, evidenced by increased independence with self care" />
<label>Functional mobility has improved, evidenced by increased independence with self care</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in MS and balance, evidenced by improved transfers and ambulation" />
<label>Gains noted in MS and balance, evidenced by improved transfers and ambulation</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S" />
<label>Gains noted in core strength, evidenced by increased ability to tolerate static standing for ADL'S</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility" />
<label>Pt continues to exhibit gains through PT intervention, evidenced by improved functional mobility</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Steady gains noted in ROM and MS evidenced by improved self care abilities" />
<label>Steady gains noted in ROM and MS evidenced by improved self care abilities</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_RP[]" value= "Gains noted in balance evidenced by improved transfers" />
<label>Gains noted in balance evidenced by improved transfers</label> </div>
<div class = "holder"></div> 
  <div class = "holder"></div>
  <div class = "holder"></div>
   <div class = "holder"></div>
  <div class = "holder"></div>
 <div class = "holder"></div>
  <div class = "holder"></div>
     
     

  
    
 
  
   <p>&nbsp;</p>
   <div class = "holder1"> <textarea style="color: red; background-color: lightyellow" name="soap_A_RP_Box" cols="100" rows="4"  ></textarea></div></div>   
            
            </div>  
            
             
             
                        
    
    <div id="tab16" class="tab_content">
            <h2>P:</h2>
            
      <div id = "container">
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical therapy to continue as planned" />
<label>Physical therapy to continue as planned</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving functional mobility" />
<label>Physical Therapy to continue to focus on improving functional mobility</label>
</div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving balance, so as to increase independence" />
<label>Physical Therapy to continue to focus on improving balance, so as to increase independence</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving core strength , so as to resume PLOF" />
<label>Physical Therapy to continue to focus on improving core strength , so as to resume PLOF</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls" />
<label>Physical Therapy to continue to focus on improving gait skills, so as to decrease risk of falls</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to continue to focus on improving community ambulation, so as to resume independence" />
<label>Physical Therapy to continue to focus on improving community ambulation, so as to resume independence</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care" />
<label>Physical Therapy  to continue to focus on improving functional reach, so as to improve independence with ADL's and self care</label> </div>
<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Continue with POC" />
<label>Continue with POC</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Discuss progress/concerns with MD" />
<label>Discuss progress/concerns with MD</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on safety awareness" />
<label>Physical Therapy to focus on safety awareness</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall" />
<label>Physical Therapy to focus on enhancing balance so as to decrease risk of debilitating fall</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus will be on work hardening to enable pt. to return to work w/o symptoms" />
<label>Focus will be on work hardening to enable pt. to return to work w/o symptoms</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to work light  duty w/o symptoms" />
<label>Focus on strengthening and decreasing debilitating pain to enable patient to work light duty w/o symptoms</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms" />
<label>Focus on strengthening and decreasing debilitating pain to enable patient to return to full duty w/o symptoms</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. discharged to HEP" />
<label>Pt. discharged to HEP</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt. has reached maximal potential, PT discharged" />
<label>Pt. has reached maximal potential, PT discharged</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Pt has achieved all established goals" />
<label>Pt has achieved all established goals</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged" />
<label>PT discharged</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "PT discharged secondary to non compliance with attendance" />
<label>PT discharged secondary to non compliance with attendance</label> </div>

<div class = "holder"><input type="checkbox" name="soap_A_P[]" value= "Plan of care established by PT" />
<label>Plan of care established by PT</label> </div>
  





<div class = "holder1"> 
  <textarea style="color: red; background-color: lightyellow" name="soap_A_P_Box" cols="100" rows="4"  ></textarea></div></div>

            
      </div>
            
         
   <div id="tab17" class="tab_content">
            <h2>Time Sheet:</h2>
            
            <p>[Therapeutic ex] &nbsp; &nbsp;&nbsp; [Neuromuscular] &nbsp;&nbsp;&nbsp; [Manual] &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;   [Gait training] &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;[Treatment time]  &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [Total minutes]</p>
 <p>
&nbsp;&nbsp;&nbsp;&nbsp;  <input type="text" name="TP_ex" value= "" size="3"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="NM" value= "" size="3"/>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="Man" value= "" size="3"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
  <input type="text" name="GT" value= "" size="3"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="TT" value= "" size="3"/>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="TM" value= "" size="5"/>
 </p>
            
            
             
                
 <input  type="submit" name="submit"  id="rhButton" value="save" />
            &nbsp; &nbsp;&nbsp;
			<?php
				$filenames="";
				$dir = "patients/";
				// Open a known directory, and proceed to read its contents
				if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
				while (($file = readdir($dh)) !== false) {
					if($file!='.'&& $file!='..')
					$filenames.="|"."$file" ;
				} closedir($dh);
				}
				}
				
				$filenames=substr($filenames, -(strlen($filenames)-1));
			
			?>
			chose the time:<select name="folderName" style= "width:80" onchange="changepatientName(this.value)">
				<option value="0">--choose the patient--</option>
				<?php
				$arr=explode("|",$filenames);
				$i=0;
				while($i<count($arr))
				{
					?>
					<option value=<?php echo$arr[$i]; ?>>
					<?php echo $arr[$i]; ?>
					</option>
					<?php
					$i++;
				}
				?>
			</select>
			<select disabled="disabled" name="patientName" style= "width:190">
				  <option value="0">--please choose the date--</option>
			</select>
			&nbsp; &nbsp;&nbsp;
			<input type="button" value="load" onclick="onclickload(patientName.value)" />
            </div>
            
            
</div>
</div>
<div style="clear: both; display: block; padding: 10px 0; text-align:center;"></div>
<div id="calendarDiv"></div>
</form>
<?php
}
?>
</body>
</html>