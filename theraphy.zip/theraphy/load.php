<?php
header('Content-Type: text/xml');
header("Cache-Control: no-cache, must-revalidate");
$q=$_GET["q"];
//$q="20120224";
$filenames="";
$dir = "patients/$q/";
// Open a known directory, and proceed to read its contents
if (is_dir($dir)) {
if ($dh = opendir($dir)) {
while (($file = readdir($dh)) !== false) {
	if($file!='.'&& $file!='..')
	$filenames.="|"."$file" ;
} closedir($dh);
}
}

$filenames=substr($filenames, -(strlen($filenames)-1));

echo $filenames;
?>
