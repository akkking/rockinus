<?php
$buff="2\n";
?>
<input type="text" value="<?php if($buff!="\n") echo $buff; ?>" />
