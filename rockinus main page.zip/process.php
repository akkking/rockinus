<html>
<body> 
<?php 
$usrname = $_POST['usrname']; 
$pswd = $_POST['pswd']; 
echo "Your rocker name is:  ". $usrname . " . and password is ".$pswd . ".<br />"; 
echo "Thank you for join Rockinus!<br />"; 
?> 
<a href="rockinus.php">Back Home</a>
</body>
</html> 