<html>
<head>
<title>Rock In U.S.</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<STYLE>
A:LINK    {Color: White; Text-Decoration: none}
A:VISITED {Color: White; Text-Decoration: none}
A:HOVER   {Color: gray}
</STYLE>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
.STYLE5 {
	color: #000000;
	font-weight: bold;
}
body,td,th {
	font-size: 14px;
}
-->
</style></head>
<body>
<div style="margin-left: 0%; margin-bottom: 10; margin-top: 8">
  <font face="Verdana, Arial, Helvetica, sans-serif"><img src="img/rockinus_logo.jpg"></font></div>
<div style="margin-bottom: 10; margin-top: 5">
<table width="1024" border="0" cellpadding="0" cellspacing="0" bgcolor="#336633" height="26">
  <tr>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">Rent & Lease</a></font></div></td>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">Buy & Sale</a></font></div></td>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">School &amp; Courses</a> </font></div></td>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">Friends &amp; Groups</a> </font></div></td>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">Profile & Resume </a></font></div></td>
    <td width="170" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="#">Wisdom Corner </div></td>
  </tr>
</table>
</div>

<font face="Verdana, Arial, Helvetica, sans-serif"><font face="Arial, Helvetica, sans-serif"><table width="1024" height="394" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="328" align="left" valign="top" style="border-right: 1px solid black; padding: 5px;">
	<form action="process.php" method="post">
	<div style="margin-top: 10">
      <table width="328" height="132" border="0" cellpadding="0" cellspacing="8">
        <tr>
          <td width="131" height="32" align="right"><strong><font face="Verdana, Arial, Helvetica, sans-serif">Rocker Name: </font></strong></td>
          <td width="179">
		    <font face="Verdana, Arial, Helvetica, sans-serif">
		    <input type="text" name="usrname" style="background-color: #EEEEEE; color: #336633; font-weight: bold;">
            </font></td>
        </tr>
        <tr>
          <td height="30" align="right"><strong><font face="Verdana, Arial, Helvetica, sans-serif">Password: </font></strong></td>
          <td><font face="Verdana, Arial, Helvetica, sans-serif">
            <input type="password" name="pswd" style="background-color: #EEEEEE; color: #336633; font-weight: bold;" size="17">
          </font></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><font face="Verdana, Arial, Helvetica, sans-serif">
            <input type="submit" name="Submit" value="Rock In">
          </font></td>
        </tr>
      </table>
	  </div>
      <p style="border-bottom: 1px dotted #000000;"></p>
    </form>
        <div style="background-color: #EEEEEE; padding-top: 15; padding-bottom: 15; padding-left: 0; border-color:#336633; border-style: solid; width:305; margin-left:10; margin-right:10; border-width: thin">
          <form enctype="multipart/form-data" action="uploader.php" method="POST">
            <font face="Verdana, Arial, Helvetica, sans-serif">
            <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
            <font face="Arial, Helvetica, sans-serif">
            <div class="STYLE5" style="padding-left:35; padding-bottom: 15;">New Rocker? Choose an icon: </div>
            </font></font>
            <div style="padding-left:45;">
              <font face="Verdana, Arial, Helvetica, sans-serif">
              <input name="uploadedfile" type="file" />
              </font></div>
            <font face="Verdana, Arial, Helvetica, sans-serif"><br />
            </font>
            <div style="padding-left:180;">
              <input name="submit" type="submit" value="Upload" />
            </div>
          </form>
        </div>
		<div style="padding-top: 5; padding-bottom: 5; margin-top: 20; margin-left:35; background-color:#336633; width: 250" align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="">Sign Up</a> &nbsp;&nbsp; |  &nbsp;&nbsp;<a href="">Password Lost?</a></font></div>	</td>
    <td width="696" align="left" valign="top"><div align="center" style="margin-left:5; margin-top: 2"><font face="Verdana, Arial, Helvetica, sans-serif"><img src="img/cover.jpg" width="679" height="390"><br />
    </font></div></td>
  </tr>
</table>
 <p style="border-bottom: 1px dotted #000000; width:1024; margin-top:-10" ></p>
</font>
<div style="margin-left:380; font: smaller" >Copyright &copy; 2011 Rockinus Inc. All rights reserved. &nbsp; &nbsp; &nbsp; </div>
<font face="Verdana, Arial, Helvetica, sans-serif"><font face="Arial, Helvetica, sans-serif">
<div style="margin-left:380; font: smaller; margin-top:5"><font face="Verdana, Arial, Helvetica, sans-serif"><font face="Verdana, Arial, Helvetica, sans-serif"><font face="Arial, Helvetica, sans-serif">About Rockinus</font></font></font>&nbsp;|&nbsp; Jobs &nbsp;|&nbsp; Contact us &nbsp;|&nbsp;&nbsp; <font color="#FF3333">Give us a feedback.</font></div>
</font></font></font>
</body>
</html>
