<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="../style.css" />
<title>&#26080;&#26631;&#39064;&#25991;&#26723;</title>
<style type="text/css">
<!--
.STYLE2 {font-size: 36px}
.STYLE3 {font-size: 14px}
-->
</style>
</head>
<body>
<div align="center"><p>
<table width="500" height="211" border="8" cellpadding="0" cellspacing="0" bordercolor="#336633">
  <tr>
    <td height="151" colspan="2" align="center" valign="middle" bgcolor="#EEEEEE" style="border-bottom:0"><span class="STYLE2">Invalid Access!</span></td>
  </tr>
  <tr>
    <td width="107" height="52" align="center" valign="middle" style="border-top:0; border-bottom:0; border-right:0"><a href="login.php" class="one STYLE3"><strong>Go  Home</strong></a></td>
    <td width="373" align="center" valign="middle" style="border-top:0; border-bottom:0; border-left:0; padding-right:15px"><div align="right"><strong>G-Unit Inventory System</strong></div></td>
  </tr>
</table>
</div>
</body>
</html>
