<html>
<head>
<title>G-Unit Records Check-in Check-out Inventory System</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
<!--
.STYLE14 {font-weight: bold}
.STYLE15 {font-size: 12px}
.STYLE16 {font-size: 13px}
.STYLE17 {color: #999999}
.STYLE18 {color: #CCCCCC}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
</head>
<body>
<div align="center" style="background: #B82929; padding-top:0px; padding-bottom:0px; border-bottom:#000000 solid 1; border-top:#000000 solid 1; margin-bottom: 0px; margin-top:0" >
  <div align="left" style="margin-left:20px">
  <table width="843" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="70"><font size="5"><a href=<?php if(isset($_SESSION['linkpage']))echo($_SESSION['linkpage']);else echo("index.php") ?>><img src="img/GUnitThisis50New_com.png" width="70" height="70" style="border:0px"></a></font></td>
      <td width="773" style="padding-left:20px">
	  <font size="5"><a href=<?php if(isset($_SESSION['linkpage']))echo($_SESSION['linkpage']);else echo("index.php") ?>>G-Unit Records Check-in Check-out Inventory System</a></font></td>
    </tr>
  </table>
  </div>
</div>
<div style="width:100%; background-color:#F9F8FE; border-bottom:1px #EEEEEE dotted; margin-bottom:15px" align="left">
 <table width="500" border="0" cellspacing="0" cellpadding="0">
   <tr>
     <td width="90" height="30" bgcolor="#EEEEEE" style=" border-bottom:1px dotted #CCCCCC; border-right:1px dotted #CCCCCC" align="center">
	 <a href="index.php" class="one"><font color="#000000" size=3>Home</font></a></td>
     <td width="90" height="30"><div align="center"></div></td>
     <td width="90" height="30"><div align="center"></div></td>
     <td width="90" height="30"><div align="center"></div></td>
     <td width="90" height="30"><div align="center"></div></td>
   </tr>
 </table>
  </div>
  </body>
</html>
