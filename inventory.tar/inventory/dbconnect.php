<?php 
$link = mysql_connect('localhost', 'root', '264gunitcamera15');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
?>
